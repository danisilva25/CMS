﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Others
{
    public class VariaveisGlobais
    {
        public static int idObject;
        public static int posicaoComputador;
        public static int laboratorio;
        public static Boolean cadastrou = false;
        public static String nomePc = "";
        public static Object usuario;
        public static Object computador;
    }
}
