﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Others
{
    public class Conexao
    {
        private String conexao = @"Data Source=.\SQLEXPRESS; Initial Catalog=dbcms; User Id=seu usuario; Password=sua senha";
        SqlConnection conn;

        public SqlConnection openConnection()
        {
            try
            {
                this.conn = new SqlConnection(this.conexao);
                this.conn.Open();
                return this.conn;
            }
            catch
            {
                Console.WriteLine("Erro ao conectar com o banco de dados");
                return null;
            }
        }
        public void closeConnection()
        {
            try
            {
                this.conn.Close();
                this.conn.Dispose();
            }
            catch
            {
                Console.WriteLine("Erro ao fechar a conexão com o banco de dados");
            }
        }
    }
}
