﻿using CMS.Domain;
using CMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    public class LaboratorioController
    {
        public LaboratorioController(){}

        public String salvarLaboratorio(LaboratorioDTO laboratorioDto)
        {
            if (laboratorioDto.descricaoLaboratorio == null)
            {
                return "O campo está vazio";
            }
            else
            {
                try
                {
                    Laboratorio laboratorio = new Laboratorio();
                    if (laboratorio.salvar(laboratorioDto))
                        return "Os dados foram salvos com sucesso";
                    else
                        return "Erro ao salvar os dados";
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro na controller ao salvar usuário! Erro; " + ex.Message);
                    return "Erro ao salvar os dados";
                }
            }               
        }
        public List<LaboratorioDTO> listar(String buscar)
        {
            try
            {
                Laboratorio laboratorio = new Laboratorio();
                return laboratorio.listar(buscar);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao listar usuário! Erro; " + ex.Message);
                return null;
            }
        }
        public LaboratorioDTO carregar(int idlaboratorio)
        {
            try
            {
                Laboratorio laboratorio = new Laboratorio();
                return laboratorio.carregar(idlaboratorio);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao carregar usuário! Erro; " + ex.Message);
                return null;
            }
        }
        public Boolean excluir(int idlaboratorio)
        {
            try
            {
                Laboratorio laboratorio = new Laboratorio();
                return laboratorio.excluir(idlaboratorio);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao acessar a Model! Erro; " + ex.Message);
                return false;
            }
        }
    }
}
