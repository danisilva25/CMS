﻿using CMS.Domain;
using CMS.Models;
using CMS.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    public class EmailController
    {
        public String salvar(EmailDTO email)
        {
            Email emailModel = new Email(); 
            try
            {
                if(email.emailAdmin.Equals(""))
                {
                    return "O campo email está vazio";
                }
                else
                {
                    if (emailModel.salvarEmail(email))
                    {
                        return "Email salvo com sucesso";
                    }
                    else
                    {
                        return "Erro na model ao salvar Email";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Erro na controller ao salvar email! Erro: " + ex.Message;
            }
        }
        public String retornaEmail()
        {
            try
            {
                EmailDAO emailDao = new EmailDAO();
                return emailDao.retornaEmail();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao retornar email! Erro: " + ex.Message);
                return null;
            }
        }
    }
}
