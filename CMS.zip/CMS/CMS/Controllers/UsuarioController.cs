﻿using CMS.Domain;
using CMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    public class UsuarioController
    {
        public UsuarioController() { }

        public String salvarUsuario(UsuarioDTO usuarioDto)
        {
            if (usuarioDto.nomeUsuario == null || usuarioDto.matriculaUsuario == null
                || usuarioDto.senhaUsuario == null)
            {
                return "Existem campos não preenchidos!";
            }
            else
            {
                try
                {
                    Usuario usuario = new Usuario();
                    if (usuario.salvarUsuario(usuarioDto))
                        return "Os dados foram salvos com sucesso!";
                    else
                        return "Erro ao salvar os dados!";
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro na controller ao salvar usuário! Erro; " + ex.Message);
                    return "Erro ao salvar os dados!";
                }
            }
                
        }
        public List<UsuarioDTO> listar(String buscar)
        {
            try
            {
                Usuario usuario = new Usuario();
                return usuario.listarUsuario(buscar);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao listar usuário! Erro; " + ex.Message);
                return null;
            }
        }
        public UsuarioDTO carregar(int idUsuario)
        {
            try
            {
                Usuario usuario = new Usuario();
                return usuario.carregarUsuario(idUsuario);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao carregar usuário! Erro; " + ex.Message);
                return null;
            }
        }
        public Boolean excluir(int idUsuario)
        {
            try
            {
                Usuario usuario = new Usuario();
                return usuario.excluirUsuario(idUsuario);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao acessar a Model! Erro; " + ex.Message);
                return false;
            }
        }
        public UsuarioDTO logar(String matricula, String senha)
        {
            try
            {
                Usuario usuario = new Usuario();
                return usuario.logar(matricula, senha);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na Controller ao logar no sistema! Erro: " + ex.Message);
                return null;
            }
        }
        public String alterarSenha(String senhaAtual, String novaSenha, String repetirSenha, int idUsuario)
        {
            String msg = "";
            try
            {
                if (senhaAtual.Equals("") || novaSenha.Equals("") || repetirSenha.Equals(""))
                {
                    msg = "Existe campos não preenchidos";
                }                   
                else if(!novaSenha.Equals(repetirSenha))
                {
                    msg = "os campos nova senha e repetir senha não conferem!";
                }
                else
                {
                    Usuario usuario = new Usuario();

                    if (usuario.alterarSenha(senhaAtual, novaSenha, idUsuario))
                    {
                        msg = "Senha alterada com sucesso!";
                    }
                    else
                    {
                        msg = "Erro ao alterar a senha";
                    }
                }
                return msg;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao alterar senha! Erro: " + ex.Message);
                return null;
            }
        }
    }
}
