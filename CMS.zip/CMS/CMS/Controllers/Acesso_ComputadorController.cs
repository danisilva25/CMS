﻿using CMS.Domain;
using CMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    public class Acesso_ComputadorController
    {
        public bool gravar(Acesso_ComputadorDTO acesso_computadorDto)
        {
            try
            {
                Acesso_Computador acesso = new Acesso_Computador();
                return acesso.gravar(acesso_computadorDto);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao gravar acesso! Erro: " + ex.Message);
                return false;
            }
        }
        public List<Acesso_ComputadorDTO> listar(DateTime data, int laboratorio)
        {
            try
            {
                Acesso_Computador acessoModel = new Acesso_Computador();
                return acessoModel.listar(data, laboratorio);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao listar acesso! Erro: " + ex.Message);
                return null;
            }
        }
        public bool excluir(DateTime? data, int posicao)
        {
            try
            {
                Acesso_Computador acesso = new Acesso_Computador();
                return acesso.excluir(data, posicao);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao excluir acessos! Erro: " + ex.Message);
                return false;
            }
        }
    }
}
