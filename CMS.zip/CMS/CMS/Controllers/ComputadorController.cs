﻿using CMS.Domain;
using CMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    class ComputadorController
    {
        public ComputadorController(){}

        public Boolean salvarComputador(ComputadorDTO computadorDto)
        {
            if (computadorDto.nomeComputador.Equals("") || computadorDto.posicaoComputador == 0 || computadorDto.laboratorio == null)
                return false;
            else
            {
                try
                {
                    Computador computador = new Computador();

                    if (computador.salvar(computadorDto))
                        return true;
                    else
                        return false;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro na Controller ao salvar Computador! Erro: " + ex.Message);
                    return false;
                }
            }
        }
        public List<ComputadorDTO> listar(string buscar)
        {
            try
            {
                Computador computador = new Computador();
                return computador.listar(buscar);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao listar computador! Erro: " + ex.Message);
                return null;
            }
        }
        public ComputadorDTO carregar(int id)
        {
            try
            {
                Computador computador = new Computador();
                return computador.carregar(id);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao carregar computador! Erro: " + ex.Message);
                return null;
            }
        }
        public Boolean excluir(int id)
        {
            try
            {
                Computador computador = new Computador();
                return computador.excluir(id);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao excluir computador! Erro: " + ex.Message);
                return false;
            }
        }
        public ComputadorDTO carregarPorNome(String nome)
        {
            try
            {
                Computador computador = new Computador();
                return computador.carregarPorNome(nome);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na controller ao carregar computador! Erro: " + ex.Message);
                return null;
            }
        }
    }
}
