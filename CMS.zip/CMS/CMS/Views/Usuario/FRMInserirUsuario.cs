﻿using CMS.Controllers;
using CMS.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CMS.Views;
using CMS.Others;

namespace CMS.Views
{
    public partial class FRMInserirUsuario : Form
    {
        public FRMInserirUsuario()
        {
            InitializeComponent();

            cbxPermissao.SelectedIndex = 0;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            UsuarioController usuarioControler = new UsuarioController();       

            if(tbxSenha.Text.Equals(tbxRepetirSenha.Text))
            {
                try
                {
                    UsuarioDTO usuario = new UsuarioDTO();
                    if (!tbxId.Text.Equals(""))
                        usuario.idUsuario = Convert.ToInt32(tbxId.Text);

                    usuario.nomeUsuario = tbxNome.Text;
                    usuario.matriculaUsuario = tbxMatricula.Text;
                    usuario.senhaUsuario = tbxSenha.Text;

                    if (cbxPermissao.SelectedIndex == 0)
                        usuario.permissaoUsuario = 0;
                    else
                        usuario.permissaoUsuario = 1;

                    MessageBox.Show(usuarioControler.salvarUsuario(usuario));
                    limparCampos();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro na view ao cadastrar usuário! Erro: " + ex.Message);
                } 
            }
            else
            {
                MessageBox.Show("As senhas são diferentes");
            }
            
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void limparCampos()
        {
            tbxId.Text = "";
            tbxNome.Text = "";
            tbxMatricula.Text = "";
            tbxSenha.Text = "";
            tbxRepetirSenha.Text = "";
            cbxPermissao.SelectedIndex = 0;
        }
    }
}
