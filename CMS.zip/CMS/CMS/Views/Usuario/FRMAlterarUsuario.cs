﻿using CMS.Controllers;
using CMS.Domain;
using CMS.Others;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.Views.Usuario
{
    public partial class FRMAlterarUsuario : Form
    {      
        public FRMAlterarUsuario()
        {
            InitializeComponent();
            try
            {               
                UsuarioController usuarioController = new UsuarioController();
                UsuarioDTO usuario = new UsuarioDTO();
                usuario = usuarioController.carregar(VariaveisGlobais.idObject);

                tbxId.Text = Convert.ToString(usuario.idUsuario);
                tbxNome.Text = usuario.nomeUsuario;
                tbxMatricula.Text = usuario.matriculaUsuario;
                if (usuario.permissaoUsuario == 1)
                    cbxPermissao.SelectedIndex = 1;
                else
                    cbxPermissao.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na view alterar usuário! Erro: " + ex.Message);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            UsuarioController usuarioControler = new UsuarioController();

            if (tbxSenha.Text.Equals(tbxRepetirSenha.Text))
            {
                try
                {
                    UsuarioDTO usuario = new UsuarioDTO();
                    if (!tbxId.Text.Equals(""))
                        usuario.idUsuario = Convert.ToInt32(tbxId.Text);

                    usuario.nomeUsuario = tbxNome.Text;
                    usuario.matriculaUsuario = tbxMatricula.Text;
                    usuario.senhaUsuario = tbxSenha.Text;

                    if (cbxPermissao.SelectedIndex == 0)
                        usuario.permissaoUsuario = 0;
                    else
                        usuario.permissaoUsuario = 1;

                    MessageBox.Show(usuarioControler.salvarUsuario(usuario));
                    limparCampos();  
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Erro na view ao cadastrar usuário! Erro: " + ex.Message);
                }              
            }
            else
            {
                MessageBox.Show("As senhas são diferentes");
            }
        }

        private void limparCampos()
        {
            tbxId.Text = "";
            tbxNome.Text = "";
            tbxMatricula.Text = "";
            tbxSenha.Text = "";
            tbxRepetirSenha.Text = "";
            cbxPermissao.SelectedIndex = 0;
        }
    }
}
