﻿using CMS.Controllers;
using CMS.Domain;
using CMS.Others;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.Views.Usuario
{
    public partial class FRMAlterarSenha : Form
    {
        public FRMAlterarSenha()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            UsuarioDTO usuarioDto = (UsuarioDTO)Convert.ChangeType(VariaveisGlobais.usuario, typeof(UsuarioDTO));
            UsuarioController usuarioController = new UsuarioController();

            MessageBox.Show(usuarioController.alterarSenha(tbxSenhaAntiga.Text, tbxNovaSenha.Text, tbxConfirmarSenha.Text, usuarioDto.idUsuario));
        }
    }
}
