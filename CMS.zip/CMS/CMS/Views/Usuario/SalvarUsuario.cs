﻿using CMS.Controllers;
using CMS.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CMS.Others;
using CMS.Views.Usuario;
namespace CMS.Views
{
    public partial class FRMUsuario : Form
    {
        public FRMUsuario()
        {
            InitializeComponent();
            listar(null);
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            FRMInserirUsuario frm = new FRMInserirUsuario();
            frm.ShowDialog();
            listar(null);
        }

        private void listar(String busca)
        {
            try
            {
                DGVUsuario.Rows.Clear();
                DGVUsuario.Refresh();
                UsuarioController usuarioController = new UsuarioController();
                List<UsuarioDTO> listaUsuarios;

                if (busca == null)
                {
                    listaUsuarios = usuarioController.listar(null);
                }                  
                else
                {
                    listaUsuarios = usuarioController.listar(busca);
                }

                foreach (var users in listaUsuarios)
                {
                    DGVUsuario.Rows.Add(users.idUsuario, users.nomeUsuario, users.matriculaUsuario,
                        permissao(users.permissaoUsuario));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao lista usuario! Erro: " + ex.Message);
            }

        }

        private String permissao(int permissao)
        {
            if (permissao == 1)
                return "Administrador";
            else
                return "Comum";
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            UsuarioController usuarioController = new UsuarioController();

            if (usuarioController.excluir(Convert.ToInt32(DGVUsuario.CurrentRow.Cells[0].Value)))
                MessageBox.Show("Usuário excluído com sucesso");
            else
                MessageBox.Show("Erro ao excluir os dados");

            for (int i = 0; i < DGVUsuario.RowCount; i++)
            {
                DGVUsuario.Rows.Clear();
                DGVUsuario.Refresh();
            }
            listar(null);
        }

        private void DGVUsuario_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {    
            VariaveisGlobais.idObject = Convert.ToInt32(DGVUsuario.CurrentRow.Cells[0].Value);
            FRMAlterarUsuario frm = new FRMAlterarUsuario();
            frm.ShowDialog();
            listar(null);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listar(TBXBuscar.Text);
        }
    }
}
