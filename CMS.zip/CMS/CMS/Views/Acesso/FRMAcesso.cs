﻿using CMS.Controllers;
using CMS.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.Views.Acesso
{
    public partial class FRMAcesso : Form
    {
        public FRMAcesso()
        {
            InitializeComponent();
            listarLaboratório();
        }

        private void listarLaboratório()
        {
            try
            {
                List<LaboratorioDTO> listalab = new List<LaboratorioDTO>();
                LaboratorioController labController = new LaboratorioController();
                listalab = labController.listar(null);

                cbxLaboratorio.DataSource = listalab;
                cbxLaboratorio.DisplayMember = "descricaoLaboratorio";
                cbxLaboratorio.ValueMember = "idLaboratorio";
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro na view FRMAcesso ao listar Laboratório! Erro: " + ex.Message);
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnVerAcesso_Click(object sender, EventArgs e)
        {
            try
            {
                dgvAcesso.Rows.Clear();
                dgvAcesso.Refresh();

                List<Acesso_ComputadorDTO> lista = new List<Acesso_ComputadorDTO>();
                Acesso_ComputadorController acessoController = new Acesso_ComputadorController();
                lista = acessoController.listar(Convert.ToDateTime(mcrData.SelectionRange.Start.ToString("dd MM yyyy")), Convert.ToInt32(cbxLaboratorio.SelectedValue));

                foreach (var access in lista)
                {
                    dgvAcesso.Rows.Add(access.dataAcesso.TimeOfDay, access.usuario.nomeUsuario, 
                        access.laboratorio.descricaoLaboratorio, access.computador.nomeComputador);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na view ao listar acessos! Erro: " + ex.Message);
            }
            
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            FRMExcluirAcesso frm = new FRMExcluirAcesso();
            frm.ShowDialog();
        }
    }
}
