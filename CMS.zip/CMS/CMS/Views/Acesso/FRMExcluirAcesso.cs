﻿using CMS.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.Views.Acesso
{
    public partial class FRMExcluirAcesso : Form
    {
        public FRMExcluirAcesso()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            try
            {
                Acesso_ComputadorController controller = new Acesso_ComputadorController();

                DialogResult resul = MessageBox.Show("Deseja realmente excluir os acessos?", "Confirmação", MessageBoxButtons.YesNo);

                if (resul == DialogResult.Yes)
                {
                    if (controller.excluir(Convert.ToDateTime(mcrData.SelectionRange.Start.ToString("dd MM yyyy")), cbxPeriodo.SelectedIndex))
                    {
                        MessageBox.Show("Os acessos forma excluídos com sucesso!");
                    }
                    else
                    {
                        MessageBox.Show("Erro ao excluir os acessos");
                    }
                }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na view ao excluir acesso! Erro: " + ex.Message);
            }

        }

        private void cbxPeriodo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cbxPeriodo.SelectedIndex == 0)
                mcrData.Enabled = true;
            else
                mcrData.Enabled = false;
        }
    }
}
