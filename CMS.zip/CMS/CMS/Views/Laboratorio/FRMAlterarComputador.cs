﻿using CMS.Controllers;
using CMS.Domain;
using CMS.Others;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.Views.Laboratorio
{
    public partial class FRMAlterarComputador : Form
    {
        public FRMAlterarComputador()
        {
            InitializeComponent();
            ComputadorController computadorController = new ComputadorController();
            computadorDto = computadorController.carregar(VariaveisGlobais.idObject);
            tbxNome.Text = computadorDto.nomeComputador;
        }
        ComputadorDTO computadorDto = new ComputadorDTO();

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            computadorDto.nomeComputador = tbxNome.Text;
            ComputadorController compController = new ComputadorController();

            if (compController.salvarComputador(computadorDto))
                MessageBox.Show("Os dados foram salvos com sucesso");
            else
                MessageBox.Show("Erro ao salvar os dados!");
                                      
            this.Dispose();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
