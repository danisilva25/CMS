﻿using CMS.Controllers;
using CMS.Domain;
using System;
using System.Collections.Generic;
namespace CMS.Views.Laboratorio
{
    partial class FRMLaboratorio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRMLaboratorio));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pbxExcluir = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pbxAdd = new System.Windows.Forms.PictureBox();
            this.cbxLaboratorio = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pbxPc1 = new System.Windows.Forms.PictureBox();
            this.pbxPc3 = new System.Windows.Forms.PictureBox();
            this.pbxPc2 = new System.Windows.Forms.PictureBox();
            this.pbxPc5 = new System.Windows.Forms.PictureBox();
            this.pbxPc6 = new System.Windows.Forms.PictureBox();
            this.pbxPc4 = new System.Windows.Forms.PictureBox();
            this.pbxPc11 = new System.Windows.Forms.PictureBox();
            this.pbxPc12 = new System.Windows.Forms.PictureBox();
            this.pbxPc10 = new System.Windows.Forms.PictureBox();
            this.pbxPc8 = new System.Windows.Forms.PictureBox();
            this.pbxPc9 = new System.Windows.Forms.PictureBox();
            this.pbxPc7 = new System.Windows.Forms.PictureBox();
            this.pbxPc17 = new System.Windows.Forms.PictureBox();
            this.pbxPc18 = new System.Windows.Forms.PictureBox();
            this.pbxPc16 = new System.Windows.Forms.PictureBox();
            this.pbxPc14 = new System.Windows.Forms.PictureBox();
            this.pbxPc15 = new System.Windows.Forms.PictureBox();
            this.pbxPc13 = new System.Windows.Forms.PictureBox();
            this.pbxPc23 = new System.Windows.Forms.PictureBox();
            this.pbxPc24 = new System.Windows.Forms.PictureBox();
            this.pbxPc22 = new System.Windows.Forms.PictureBox();
            this.pbxPc20 = new System.Windows.Forms.PictureBox();
            this.pbxPc21 = new System.Windows.Forms.PictureBox();
            this.pbxPc19 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblNomePc24 = new System.Windows.Forms.Label();
            this.lblNomePc23 = new System.Windows.Forms.Label();
            this.lblNomePc22 = new System.Windows.Forms.Label();
            this.lblNomePc21 = new System.Windows.Forms.Label();
            this.lblNomePc20 = new System.Windows.Forms.Label();
            this.lblNomePc19 = new System.Windows.Forms.Label();
            this.lblNomePc18 = new System.Windows.Forms.Label();
            this.lblNomePc17 = new System.Windows.Forms.Label();
            this.lblNomePc16 = new System.Windows.Forms.Label();
            this.lblNomePc15 = new System.Windows.Forms.Label();
            this.lblNomePc14 = new System.Windows.Forms.Label();
            this.lblNomePc13 = new System.Windows.Forms.Label();
            this.lblNomePc12 = new System.Windows.Forms.Label();
            this.lblNomePc11 = new System.Windows.Forms.Label();
            this.lblNomePc10 = new System.Windows.Forms.Label();
            this.lblNomePc9 = new System.Windows.Forms.Label();
            this.lblNomePc8 = new System.Windows.Forms.Label();
            this.lblNomePc7 = new System.Windows.Forms.Label();
            this.lblNomePc6 = new System.Windows.Forms.Label();
            this.lblNomePc5 = new System.Windows.Forms.Label();
            this.lblNomePc4 = new System.Windows.Forms.Label();
            this.lblNomePc3 = new System.Windows.Forms.Label();
            this.lblNomePc2 = new System.Windows.Forms.Label();
            this.lblNomePc = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxExcluir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc19)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.pbxExcluir);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.pbxAdd);
            this.groupBox1.Controls.Add(this.cbxLaboratorio);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(436, 65);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastro de Laboratorio";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(392, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "Excluir";
            // 
            // pbxExcluir
            // 
            this.pbxExcluir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxExcluir.BackgroundImage")));
            this.pbxExcluir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxExcluir.InitialImage = null;
            this.pbxExcluir.Location = new System.Drawing.Point(393, 9);
            this.pbxExcluir.Name = "pbxExcluir";
            this.pbxExcluir.Size = new System.Drawing.Size(34, 40);
            this.pbxExcluir.TabIndex = 35;
            this.pbxExcluir.TabStop = false;
            this.pbxExcluir.Click += new System.EventHandler(this.pbxExcluir_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(291, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 34;
            this.label2.Text = "Adicionar";
            // 
            // pbxAdd
            // 
            this.pbxAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxAdd.BackgroundImage")));
            this.pbxAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxAdd.Location = new System.Drawing.Point(298, 9);
            this.pbxAdd.Name = "pbxAdd";
            this.pbxAdd.Size = new System.Drawing.Size(33, 40);
            this.pbxAdd.TabIndex = 1;
            this.pbxAdd.TabStop = false;
            this.pbxAdd.Click += new System.EventHandler(this.pbxAdd_Click);
            // 
            // cbxLaboratorio
            // 
            this.cbxLaboratorio.FormattingEnabled = true;
            this.cbxLaboratorio.Location = new System.Drawing.Point(73, 28);
            this.cbxLaboratorio.Name = "cbxLaboratorio";
            this.cbxLaboratorio.Size = new System.Drawing.Size(160, 21);
            this.cbxLaboratorio.TabIndex = 1;
            this.cbxLaboratorio.SelectedIndexChanged += new System.EventHandler(this.cbxLaboratorio_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Laboratorio";
            // 
            // pbxPc1
            // 
            this.pbxPc1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc1.BackgroundImage")));
            this.pbxPc1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc1.Location = new System.Drawing.Point(6, 37);
            this.pbxPc1.Name = "pbxPc1";
            this.pbxPc1.Size = new System.Drawing.Size(48, 58);
            this.pbxPc1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxPc1.TabIndex = 1;
            this.pbxPc1.TabStop = false;
            this.pbxPc1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc1_MouseClick);
            // 
            // pbxPc3
            // 
            this.pbxPc3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc3.BackgroundImage")));
            this.pbxPc3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc3.Location = new System.Drawing.Point(133, 37);
            this.pbxPc3.Name = "pbxPc3";
            this.pbxPc3.Size = new System.Drawing.Size(48, 58);
            this.pbxPc3.TabIndex = 2;
            this.pbxPc3.TabStop = false;
            this.pbxPc3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc3_MouseClick);
            // 
            // pbxPc2
            // 
            this.pbxPc2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc2.BackgroundImage")));
            this.pbxPc2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc2.Location = new System.Drawing.Point(70, 37);
            this.pbxPc2.Name = "pbxPc2";
            this.pbxPc2.Size = new System.Drawing.Size(48, 58);
            this.pbxPc2.TabIndex = 3;
            this.pbxPc2.TabStop = false;
            this.pbxPc2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc2_MouseClick);
            // 
            // pbxPc5
            // 
            this.pbxPc5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc5.BackgroundImage")));
            this.pbxPc5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc5.Location = new System.Drawing.Point(316, 37);
            this.pbxPc5.Name = "pbxPc5";
            this.pbxPc5.Size = new System.Drawing.Size(48, 58);
            this.pbxPc5.TabIndex = 6;
            this.pbxPc5.TabStop = false;
            this.pbxPc5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc5_MouseClick);
            // 
            // pbxPc6
            // 
            this.pbxPc6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc6.BackgroundImage")));
            this.pbxPc6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc6.Location = new System.Drawing.Point(379, 37);
            this.pbxPc6.Name = "pbxPc6";
            this.pbxPc6.Size = new System.Drawing.Size(48, 58);
            this.pbxPc6.TabIndex = 5;
            this.pbxPc6.TabStop = false;
            this.pbxPc6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc6_MouseClick);
            // 
            // pbxPc4
            // 
            this.pbxPc4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc4.BackgroundImage")));
            this.pbxPc4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc4.Location = new System.Drawing.Point(249, 37);
            this.pbxPc4.Name = "pbxPc4";
            this.pbxPc4.Size = new System.Drawing.Size(48, 58);
            this.pbxPc4.TabIndex = 4;
            this.pbxPc4.TabStop = false;
            this.pbxPc4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc4_MouseClick);
            // 
            // pbxPc11
            // 
            this.pbxPc11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc11.BackgroundImage")));
            this.pbxPc11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc11.Location = new System.Drawing.Point(316, 141);
            this.pbxPc11.Name = "pbxPc11";
            this.pbxPc11.Size = new System.Drawing.Size(48, 58);
            this.pbxPc11.TabIndex = 15;
            this.pbxPc11.TabStop = false;
            this.pbxPc11.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc11_MouseClick);
            // 
            // pbxPc12
            // 
            this.pbxPc12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc12.BackgroundImage")));
            this.pbxPc12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc12.Location = new System.Drawing.Point(379, 141);
            this.pbxPc12.Name = "pbxPc12";
            this.pbxPc12.Size = new System.Drawing.Size(48, 58);
            this.pbxPc12.TabIndex = 14;
            this.pbxPc12.TabStop = false;
            this.pbxPc12.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc12_MouseClick);
            // 
            // pbxPc10
            // 
            this.pbxPc10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc10.BackgroundImage")));
            this.pbxPc10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc10.Location = new System.Drawing.Point(249, 141);
            this.pbxPc10.Name = "pbxPc10";
            this.pbxPc10.Size = new System.Drawing.Size(48, 58);
            this.pbxPc10.TabIndex = 13;
            this.pbxPc10.TabStop = false;
            this.pbxPc10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc10_MouseClick);
            // 
            // pbxPc8
            // 
            this.pbxPc8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc8.BackgroundImage")));
            this.pbxPc8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc8.Location = new System.Drawing.Point(70, 141);
            this.pbxPc8.Name = "pbxPc8";
            this.pbxPc8.Size = new System.Drawing.Size(48, 58);
            this.pbxPc8.TabIndex = 12;
            this.pbxPc8.TabStop = false;
            this.pbxPc8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc8_MouseClick);
            // 
            // pbxPc9
            // 
            this.pbxPc9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc9.BackgroundImage")));
            this.pbxPc9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc9.Location = new System.Drawing.Point(133, 141);
            this.pbxPc9.Name = "pbxPc9";
            this.pbxPc9.Size = new System.Drawing.Size(48, 58);
            this.pbxPc9.TabIndex = 11;
            this.pbxPc9.TabStop = false;
            this.pbxPc9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc9_MouseClick);
            // 
            // pbxPc7
            // 
            this.pbxPc7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc7.BackgroundImage")));
            this.pbxPc7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc7.Location = new System.Drawing.Point(6, 141);
            this.pbxPc7.Name = "pbxPc7";
            this.pbxPc7.Size = new System.Drawing.Size(48, 58);
            this.pbxPc7.TabIndex = 10;
            this.pbxPc7.TabStop = false;
            this.pbxPc7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc7_MouseClick);
            // 
            // pbxPc17
            // 
            this.pbxPc17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc17.BackgroundImage")));
            this.pbxPc17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc17.Location = new System.Drawing.Point(316, 239);
            this.pbxPc17.Name = "pbxPc17";
            this.pbxPc17.Size = new System.Drawing.Size(48, 58);
            this.pbxPc17.TabIndex = 24;
            this.pbxPc17.TabStop = false;
            this.pbxPc17.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc17_MouseClick);
            // 
            // pbxPc18
            // 
            this.pbxPc18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc18.BackgroundImage")));
            this.pbxPc18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc18.Location = new System.Drawing.Point(379, 239);
            this.pbxPc18.Name = "pbxPc18";
            this.pbxPc18.Size = new System.Drawing.Size(48, 58);
            this.pbxPc18.TabIndex = 23;
            this.pbxPc18.TabStop = false;
            this.pbxPc18.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc18_MouseClick);
            // 
            // pbxPc16
            // 
            this.pbxPc16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc16.BackgroundImage")));
            this.pbxPc16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc16.Location = new System.Drawing.Point(249, 239);
            this.pbxPc16.Name = "pbxPc16";
            this.pbxPc16.Size = new System.Drawing.Size(48, 58);
            this.pbxPc16.TabIndex = 22;
            this.pbxPc16.TabStop = false;
            this.pbxPc16.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc16_MouseClick);
            // 
            // pbxPc14
            // 
            this.pbxPc14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc14.BackgroundImage")));
            this.pbxPc14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc14.Location = new System.Drawing.Point(70, 239);
            this.pbxPc14.Name = "pbxPc14";
            this.pbxPc14.Size = new System.Drawing.Size(48, 58);
            this.pbxPc14.TabIndex = 21;
            this.pbxPc14.TabStop = false;
            this.pbxPc14.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc14_MouseClick);
            // 
            // pbxPc15
            // 
            this.pbxPc15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc15.BackgroundImage")));
            this.pbxPc15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc15.Location = new System.Drawing.Point(133, 239);
            this.pbxPc15.Name = "pbxPc15";
            this.pbxPc15.Size = new System.Drawing.Size(48, 58);
            this.pbxPc15.TabIndex = 20;
            this.pbxPc15.TabStop = false;
            this.pbxPc15.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc15_MouseClick);
            // 
            // pbxPc13
            // 
            this.pbxPc13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc13.BackgroundImage")));
            this.pbxPc13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc13.Location = new System.Drawing.Point(6, 239);
            this.pbxPc13.Name = "pbxPc13";
            this.pbxPc13.Size = new System.Drawing.Size(48, 58);
            this.pbxPc13.TabIndex = 19;
            this.pbxPc13.TabStop = false;
            this.pbxPc13.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc13_MouseClick);
            // 
            // pbxPc23
            // 
            this.pbxPc23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc23.BackgroundImage")));
            this.pbxPc23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc23.Location = new System.Drawing.Point(316, 338);
            this.pbxPc23.Name = "pbxPc23";
            this.pbxPc23.Size = new System.Drawing.Size(48, 58);
            this.pbxPc23.TabIndex = 33;
            this.pbxPc23.TabStop = false;
            this.pbxPc23.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc23_MouseClick);
            // 
            // pbxPc24
            // 
            this.pbxPc24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc24.BackgroundImage")));
            this.pbxPc24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc24.Location = new System.Drawing.Point(379, 338);
            this.pbxPc24.Name = "pbxPc24";
            this.pbxPc24.Size = new System.Drawing.Size(48, 58);
            this.pbxPc24.TabIndex = 32;
            this.pbxPc24.TabStop = false;
            this.pbxPc24.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc24_MouseClick);
            // 
            // pbxPc22
            // 
            this.pbxPc22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc22.BackgroundImage")));
            this.pbxPc22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc22.Location = new System.Drawing.Point(249, 338);
            this.pbxPc22.Name = "pbxPc22";
            this.pbxPc22.Size = new System.Drawing.Size(48, 58);
            this.pbxPc22.TabIndex = 31;
            this.pbxPc22.TabStop = false;
            this.pbxPc22.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc22_MouseClick);
            // 
            // pbxPc20
            // 
            this.pbxPc20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc20.BackgroundImage")));
            this.pbxPc20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc20.Location = new System.Drawing.Point(70, 338);
            this.pbxPc20.Name = "pbxPc20";
            this.pbxPc20.Size = new System.Drawing.Size(48, 58);
            this.pbxPc20.TabIndex = 30;
            this.pbxPc20.TabStop = false;
            this.pbxPc20.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc20_MouseClick);
            // 
            // pbxPc21
            // 
            this.pbxPc21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc21.BackgroundImage")));
            this.pbxPc21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc21.Location = new System.Drawing.Point(133, 338);
            this.pbxPc21.Name = "pbxPc21";
            this.pbxPc21.Size = new System.Drawing.Size(48, 58);
            this.pbxPc21.TabIndex = 29;
            this.pbxPc21.TabStop = false;
            this.pbxPc21.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc21_MouseClick);
            // 
            // pbxPc19
            // 
            this.pbxPc19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPc19.BackgroundImage")));
            this.pbxPc19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPc19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxPc19.Location = new System.Drawing.Point(6, 338);
            this.pbxPc19.Name = "pbxPc19";
            this.pbxPc19.Size = new System.Drawing.Size(48, 58);
            this.pbxPc19.TabIndex = 28;
            this.pbxPc19.TabStop = false;
            this.pbxPc19.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxPc19_MouseClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblNomePc24);
            this.groupBox2.Controls.Add(this.lblNomePc23);
            this.groupBox2.Controls.Add(this.lblNomePc22);
            this.groupBox2.Controls.Add(this.lblNomePc21);
            this.groupBox2.Controls.Add(this.lblNomePc20);
            this.groupBox2.Controls.Add(this.lblNomePc19);
            this.groupBox2.Controls.Add(this.lblNomePc18);
            this.groupBox2.Controls.Add(this.lblNomePc17);
            this.groupBox2.Controls.Add(this.lblNomePc16);
            this.groupBox2.Controls.Add(this.lblNomePc15);
            this.groupBox2.Controls.Add(this.lblNomePc14);
            this.groupBox2.Controls.Add(this.lblNomePc13);
            this.groupBox2.Controls.Add(this.lblNomePc12);
            this.groupBox2.Controls.Add(this.lblNomePc11);
            this.groupBox2.Controls.Add(this.lblNomePc10);
            this.groupBox2.Controls.Add(this.lblNomePc9);
            this.groupBox2.Controls.Add(this.lblNomePc8);
            this.groupBox2.Controls.Add(this.lblNomePc7);
            this.groupBox2.Controls.Add(this.lblNomePc6);
            this.groupBox2.Controls.Add(this.lblNomePc5);
            this.groupBox2.Controls.Add(this.lblNomePc4);
            this.groupBox2.Controls.Add(this.lblNomePc3);
            this.groupBox2.Controls.Add(this.lblNomePc2);
            this.groupBox2.Controls.Add(this.lblNomePc);
            this.groupBox2.Controls.Add(this.pbxPc1);
            this.groupBox2.Controls.Add(this.pbxPc23);
            this.groupBox2.Controls.Add(this.pbxPc3);
            this.groupBox2.Controls.Add(this.pbxPc24);
            this.groupBox2.Controls.Add(this.pbxPc2);
            this.groupBox2.Controls.Add(this.pbxPc22);
            this.groupBox2.Controls.Add(this.pbxPc4);
            this.groupBox2.Controls.Add(this.pbxPc20);
            this.groupBox2.Controls.Add(this.pbxPc6);
            this.groupBox2.Controls.Add(this.pbxPc21);
            this.groupBox2.Controls.Add(this.pbxPc5);
            this.groupBox2.Controls.Add(this.pbxPc19);
            this.groupBox2.Controls.Add(this.pbxPc7);
            this.groupBox2.Controls.Add(this.pbxPc17);
            this.groupBox2.Controls.Add(this.pbxPc9);
            this.groupBox2.Controls.Add(this.pbxPc18);
            this.groupBox2.Controls.Add(this.pbxPc8);
            this.groupBox2.Controls.Add(this.pbxPc16);
            this.groupBox2.Controls.Add(this.pbxPc10);
            this.groupBox2.Controls.Add(this.pbxPc14);
            this.groupBox2.Controls.Add(this.pbxPc12);
            this.groupBox2.Controls.Add(this.pbxPc15);
            this.groupBox2.Controls.Add(this.pbxPc11);
            this.groupBox2.Controls.Add(this.pbxPc13);
            this.groupBox2.Location = new System.Drawing.Point(13, 85);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(436, 425);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Inserir Computadores";
            // 
            // lblNomePc24
            // 
            this.lblNomePc24.AutoSize = true;
            this.lblNomePc24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc24.Location = new System.Drawing.Point(381, 388);
            this.lblNomePc24.Name = "lblNomePc24";
            this.lblNomePc24.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc24.TabIndex = 57;
            // 
            // lblNomePc23
            // 
            this.lblNomePc23.AutoSize = true;
            this.lblNomePc23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc23.Location = new System.Drawing.Point(318, 388);
            this.lblNomePc23.Name = "lblNomePc23";
            this.lblNomePc23.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc23.TabIndex = 56;
            // 
            // lblNomePc22
            // 
            this.lblNomePc22.AutoSize = true;
            this.lblNomePc22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc22.Location = new System.Drawing.Point(251, 388);
            this.lblNomePc22.Name = "lblNomePc22";
            this.lblNomePc22.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc22.TabIndex = 55;
            // 
            // lblNomePc21
            // 
            this.lblNomePc21.AutoSize = true;
            this.lblNomePc21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc21.Location = new System.Drawing.Point(135, 388);
            this.lblNomePc21.Name = "lblNomePc21";
            this.lblNomePc21.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc21.TabIndex = 54;
            // 
            // lblNomePc20
            // 
            this.lblNomePc20.AutoSize = true;
            this.lblNomePc20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc20.Location = new System.Drawing.Point(72, 388);
            this.lblNomePc20.Name = "lblNomePc20";
            this.lblNomePc20.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc20.TabIndex = 53;
            // 
            // lblNomePc19
            // 
            this.lblNomePc19.AutoSize = true;
            this.lblNomePc19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc19.Location = new System.Drawing.Point(8, 388);
            this.lblNomePc19.Name = "lblNomePc19";
            this.lblNomePc19.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc19.TabIndex = 52;
            // 
            // lblNomePc18
            // 
            this.lblNomePc18.AutoSize = true;
            this.lblNomePc18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc18.Location = new System.Drawing.Point(381, 289);
            this.lblNomePc18.Name = "lblNomePc18";
            this.lblNomePc18.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc18.TabIndex = 51;
            // 
            // lblNomePc17
            // 
            this.lblNomePc17.AutoSize = true;
            this.lblNomePc17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc17.Location = new System.Drawing.Point(318, 289);
            this.lblNomePc17.Name = "lblNomePc17";
            this.lblNomePc17.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc17.TabIndex = 50;
            // 
            // lblNomePc16
            // 
            this.lblNomePc16.AutoSize = true;
            this.lblNomePc16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc16.Location = new System.Drawing.Point(251, 289);
            this.lblNomePc16.Name = "lblNomePc16";
            this.lblNomePc16.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc16.TabIndex = 49;
            // 
            // lblNomePc15
            // 
            this.lblNomePc15.AutoSize = true;
            this.lblNomePc15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc15.Location = new System.Drawing.Point(135, 289);
            this.lblNomePc15.Name = "lblNomePc15";
            this.lblNomePc15.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc15.TabIndex = 48;
            // 
            // lblNomePc14
            // 
            this.lblNomePc14.AutoSize = true;
            this.lblNomePc14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc14.Location = new System.Drawing.Point(72, 289);
            this.lblNomePc14.Name = "lblNomePc14";
            this.lblNomePc14.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc14.TabIndex = 47;
            // 
            // lblNomePc13
            // 
            this.lblNomePc13.AutoSize = true;
            this.lblNomePc13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc13.Location = new System.Drawing.Point(9, 289);
            this.lblNomePc13.Name = "lblNomePc13";
            this.lblNomePc13.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc13.TabIndex = 46;
            // 
            // lblNomePc12
            // 
            this.lblNomePc12.AutoSize = true;
            this.lblNomePc12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc12.Location = new System.Drawing.Point(381, 191);
            this.lblNomePc12.Name = "lblNomePc12";
            this.lblNomePc12.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc12.TabIndex = 45;
            // 
            // lblNomePc11
            // 
            this.lblNomePc11.AutoSize = true;
            this.lblNomePc11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc11.Location = new System.Drawing.Point(318, 191);
            this.lblNomePc11.Name = "lblNomePc11";
            this.lblNomePc11.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc11.TabIndex = 44;
            // 
            // lblNomePc10
            // 
            this.lblNomePc10.AutoSize = true;
            this.lblNomePc10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc10.Location = new System.Drawing.Point(251, 191);
            this.lblNomePc10.Name = "lblNomePc10";
            this.lblNomePc10.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc10.TabIndex = 43;
            // 
            // lblNomePc9
            // 
            this.lblNomePc9.AutoSize = true;
            this.lblNomePc9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc9.Location = new System.Drawing.Point(135, 191);
            this.lblNomePc9.Name = "lblNomePc9";
            this.lblNomePc9.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc9.TabIndex = 42;
            // 
            // lblNomePc8
            // 
            this.lblNomePc8.AutoSize = true;
            this.lblNomePc8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc8.Location = new System.Drawing.Point(72, 191);
            this.lblNomePc8.Name = "lblNomePc8";
            this.lblNomePc8.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc8.TabIndex = 41;
            // 
            // lblNomePc7
            // 
            this.lblNomePc7.AutoSize = true;
            this.lblNomePc7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc7.Location = new System.Drawing.Point(9, 191);
            this.lblNomePc7.Name = "lblNomePc7";
            this.lblNomePc7.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc7.TabIndex = 40;
            // 
            // lblNomePc6
            // 
            this.lblNomePc6.AutoSize = true;
            this.lblNomePc6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc6.Location = new System.Drawing.Point(381, 85);
            this.lblNomePc6.Name = "lblNomePc6";
            this.lblNomePc6.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc6.TabIndex = 39;
            // 
            // lblNomePc5
            // 
            this.lblNomePc5.AutoSize = true;
            this.lblNomePc5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc5.Location = new System.Drawing.Point(318, 85);
            this.lblNomePc5.Name = "lblNomePc5";
            this.lblNomePc5.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc5.TabIndex = 38;
            // 
            // lblNomePc4
            // 
            this.lblNomePc4.AutoSize = true;
            this.lblNomePc4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc4.Location = new System.Drawing.Point(251, 85);
            this.lblNomePc4.Name = "lblNomePc4";
            this.lblNomePc4.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc4.TabIndex = 37;
            // 
            // lblNomePc3
            // 
            this.lblNomePc3.AutoSize = true;
            this.lblNomePc3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc3.Location = new System.Drawing.Point(135, 85);
            this.lblNomePc3.Name = "lblNomePc3";
            this.lblNomePc3.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc3.TabIndex = 36;
            // 
            // lblNomePc2
            // 
            this.lblNomePc2.AutoSize = true;
            this.lblNomePc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc2.Location = new System.Drawing.Point(72, 85);
            this.lblNomePc2.Name = "lblNomePc2";
            this.lblNomePc2.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc2.TabIndex = 35;
            // 
            // lblNomePc
            // 
            this.lblNomePc.AutoSize = true;
            this.lblNomePc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePc.Location = new System.Drawing.Point(9, 85);
            this.lblNomePc.Name = "lblNomePc";
            this.lblNomePc.Size = new System.Drawing.Size(0, 13);
            this.lblNomePc.TabIndex = 34;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(348, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 40);
            this.pictureBox1.TabIndex = 36;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 35;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(348, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 58;
            this.label5.Text = "Editar";
            // 
            // FRMLaboratorio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(463, 531);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "FRMLaboratorio";
            this.Text = "Laboratorio";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxExcluir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPc19)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbxLaboratorio;
        private System.Windows.Forms.PictureBox pbxAdd;
        private System.Windows.Forms.PictureBox pbxPc1;
        private System.Windows.Forms.PictureBox pbxPc3;
        private System.Windows.Forms.PictureBox pbxPc2;
        private System.Windows.Forms.PictureBox pbxPc5;
        private System.Windows.Forms.PictureBox pbxPc6;
        private System.Windows.Forms.PictureBox pbxPc4;
        private System.Windows.Forms.PictureBox pbxPc11;
        private System.Windows.Forms.PictureBox pbxPc12;
        private System.Windows.Forms.PictureBox pbxPc10;
        private System.Windows.Forms.PictureBox pbxPc8;
        private System.Windows.Forms.PictureBox pbxPc9;
        private System.Windows.Forms.PictureBox pbxPc7;
        private System.Windows.Forms.PictureBox pbxPc17;
        private System.Windows.Forms.PictureBox pbxPc18;
        private System.Windows.Forms.PictureBox pbxPc16;
        private System.Windows.Forms.PictureBox pbxPc14;
        private System.Windows.Forms.PictureBox pbxPc15;
        private System.Windows.Forms.PictureBox pbxPc13;
        private System.Windows.Forms.PictureBox pbxPc23;
        private System.Windows.Forms.PictureBox pbxPc24;
        private System.Windows.Forms.PictureBox pbxPc22;
        private System.Windows.Forms.PictureBox pbxPc20;
        private System.Windows.Forms.PictureBox pbxPc21;
        private System.Windows.Forms.PictureBox pbxPc19;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbxExcluir;
        private System.Windows.Forms.Label lblNomePc;
        private System.Windows.Forms.Label lblNomePc2;
        private System.Windows.Forms.Label lblNomePc3;
        private System.Windows.Forms.Label lblNomePc4;
        private System.Windows.Forms.Label lblNomePc5;
        private System.Windows.Forms.Label lblNomePc6;
        private System.Windows.Forms.Label lblNomePc7;
        private System.Windows.Forms.Label lblNomePc8;
        private System.Windows.Forms.Label lblNomePc12;
        private System.Windows.Forms.Label lblNomePc11;
        private System.Windows.Forms.Label lblNomePc10;
        private System.Windows.Forms.Label lblNomePc9;
        private System.Windows.Forms.Label lblNomePc13;
        private System.Windows.Forms.Label lblNomePc18;
        private System.Windows.Forms.Label lblNomePc17;
        private System.Windows.Forms.Label lblNomePc16;
        private System.Windows.Forms.Label lblNomePc15;
        private System.Windows.Forms.Label lblNomePc14;
        private System.Windows.Forms.Label lblNomePc24;
        private System.Windows.Forms.Label lblNomePc23;
        private System.Windows.Forms.Label lblNomePc22;
        private System.Windows.Forms.Label lblNomePc21;
        private System.Windows.Forms.Label lblNomePc20;
        private System.Windows.Forms.Label lblNomePc19;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
    }
}