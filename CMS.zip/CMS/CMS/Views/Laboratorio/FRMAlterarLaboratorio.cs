﻿using CMS.Controllers;
using CMS.Domain;
using CMS.Others;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.Views.Laboratorio
{
    public partial class FRMAlterarLaboratorio : Form
    {
        public FRMAlterarLaboratorio()
        {
            InitializeComponent();
            LaboratorioDTO labDto = new LaboratorioDTO();

            LaboratorioController lab = new LaboratorioController();
            labDto = lab.carregar(VariaveisGlobais.idObject);

            tbxId.Text = Convert.ToString(labDto.idLaboratorio);
            tbxDescricao.Text = labDto.descricaoLaboratorio;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            LaboratorioController lab = new LaboratorioController();
            LaboratorioDTO labDto = new LaboratorioDTO();

            labDto.idLaboratorio = Convert.ToInt32(tbxId.Text);
            labDto.descricaoLaboratorio = tbxDescricao.Text;

            MessageBox.Show(lab.salvarLaboratorio(labDto));
        }
    }
}
