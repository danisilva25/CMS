﻿using CMS.Controllers;
using CMS.Domain;
using CMS.Others;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.Views.Laboratorio
{
    public partial class FRMLaboratorio : Form
    {
        public FRMLaboratorio()
        {
            InitializeComponent();
            listar();
            listarComputadores();          
        }

        List<ComputadorDTO> listaPc = new List<ComputadorDTO>();
        private void pbxAdd_Click(object sender, EventArgs e)
        {
            FRMInserirLaboratorio frm = new FRMInserirLaboratorio();
            frm.ShowDialog();
            listar();
        }

        private void listar()
        {
            List<LaboratorioDTO> listaLab = new List<LaboratorioDTO>();
            LaboratorioController laboratorioController = new LaboratorioController();
            listaLab = laboratorioController.listar(null);

            cbxLaboratorio.DataSource = listaLab;
            cbxLaboratorio.DisplayMember = "descricaoLaboratorio";
            cbxLaboratorio.ValueMember = "idLaboratorio";
        }

        private void listarComputadores()
        {
            ComputadorController computadorController = new ComputadorController();
            listaPc = computadorController.listar(Convert.ToString(cbxLaboratorio.SelectedValue));

            foreach (var dados in listaPc)
            {
                if (dados.posicaoComputador == 1)
                {
                    pbxPc1.BackgroundImage = null;
                    pbxPc1.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc.Text = dados.nomeComputador;
                    pbxPc1.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 2)
                {
                    pbxPc2.BackgroundImage = null;
                    pbxPc2.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc2.Text = dados.nomeComputador;
                    pbxPc2.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 3)
                {
                    pbxPc3.BackgroundImage = null;
                    pbxPc3.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc3.Text = dados.nomeComputador;
                    pbxPc3.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 4)
                {
                    pbxPc4.BackgroundImage = null;
                    pbxPc4.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc4.Text = dados.nomeComputador;
                    pbxPc4.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 5)
                {
                    pbxPc5.BackgroundImage = null;
                    pbxPc5.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc5.Text = dados.nomeComputador;
                    pbxPc5.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 6)
                {
                    pbxPc6.BackgroundImage = null;
                    pbxPc6.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc6.Text = dados.nomeComputador;
                    pbxPc6.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 7)
                {
                    pbxPc7.BackgroundImage = null;
                    pbxPc7.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc7.Text = dados.nomeComputador;
                    pbxPc7.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 8)
                {
                    pbxPc8.BackgroundImage = null;
                    pbxPc8.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc8.Text = dados.nomeComputador;
                    pbxPc8.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 9)
                {
                    pbxPc9.BackgroundImage = null;
                    pbxPc9.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc9.Text = dados.nomeComputador;
                    pbxPc9.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 10)
                {
                    pbxPc10.BackgroundImage = null;
                    pbxPc10.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc10.Text = dados.nomeComputador;
                    pbxPc10.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 11)
                {
                    pbxPc11.BackgroundImage = null;
                    pbxPc11.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc11.Text = dados.nomeComputador;
                    pbxPc11.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 12)
                {
                    pbxPc12.BackgroundImage = null;
                    pbxPc12.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc12.Text = dados.nomeComputador;
                    pbxPc12.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 13)
                {
                    pbxPc13.BackgroundImage = null;
                    pbxPc13.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc13.Text = dados.nomeComputador;
                    pbxPc13.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 14)
                {
                    pbxPc14.BackgroundImage = null;
                    pbxPc14.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc14.Text = dados.nomeComputador;
                    pbxPc14.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 15)
                {
                    pbxPc15.BackgroundImage = null;
                    pbxPc15.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc15.Text = dados.nomeComputador;
                    pbxPc15.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 16)
                {
                    pbxPc16.BackgroundImage = null;
                    pbxPc16.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc16.Text = dados.nomeComputador;
                    pbxPc16.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 17)
                {
                    pbxPc17.BackgroundImage = null;
                    pbxPc17.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc17.Text = dados.nomeComputador;
                    pbxPc17.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 18)
                {
                    pbxPc18.BackgroundImage = null;
                    pbxPc18.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc18.Text = dados.nomeComputador;
                    pbxPc18.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 19)
                {
                    pbxPc19.BackgroundImage = null;
                    pbxPc19.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc19.Text = dados.nomeComputador;
                    pbxPc19.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 20)
                {
                    pbxPc20.BackgroundImage = null;
                    pbxPc20.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc20.Text = dados.nomeComputador;
                    pbxPc20.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 21)
                {
                    pbxPc21.BackgroundImage = null;
                    pbxPc21.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc21.Text = dados.nomeComputador;
                    pbxPc21.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 22)
                {
                    pbxPc22.BackgroundImage = null;
                    pbxPc22.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc22.Text = dados.nomeComputador;
                    pbxPc22.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 23)
                {
                    pbxPc23.BackgroundImage = null;
                    pbxPc23.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc23.Text = dados.nomeComputador;
                    pbxPc23.BackgroundImageLayout = ImageLayout.Center;
                }
                if (dados.posicaoComputador == 24)
                {
                    pbxPc24.BackgroundImage = null;
                    pbxPc24.BackgroundImage = Image.FromFile(@"..\..\Imagens\computador32.png");
                    lblNomePc24.Text = dados.nomeComputador;
                    pbxPc24.BackgroundImageLayout = ImageLayout.Center;
                }
            }
        }

        private void limparComputadores()
        {
            //pbxPc1
            pbxPc1.BackgroundImage = null;
            pbxPc1.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc.Text = "";
            pbxPc1.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc2
            pbxPc2.BackgroundImage = null;
            pbxPc2.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc2.Text = "";
            pbxPc2.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc3
            pbxPc3.BackgroundImage = null;
            pbxPc3.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc3.Text = "";
            pbxPc3.BackgroundImageLayout = ImageLayout.Center;
            
            //pbxPc4
            pbxPc4.BackgroundImage = null;
            pbxPc4.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc4.Text = "";
            pbxPc4.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc5
            pbxPc5.BackgroundImage = null;
            pbxPc5.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc5.Text = "";
            pbxPc5.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc6
            pbxPc6.BackgroundImage = null;
            pbxPc6.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc6.Text = "";
            pbxPc6.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc7
            pbxPc7.BackgroundImage = null;
            pbxPc7.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc7.Text = "";
            pbxPc7.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc8
            pbxPc8.BackgroundImage = null;
            pbxPc8.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc8.Text = "";
            pbxPc8.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc9
            pbxPc9.BackgroundImage = null;
            pbxPc9.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc9.Text = "";
            pbxPc9.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc10
            pbxPc10.BackgroundImage = null;
            pbxPc10.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc10.Text = "";
            pbxPc10.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc11
            pbxPc11.BackgroundImage = null;
            pbxPc11.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc11.Text = "";
            pbxPc11.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc12
            pbxPc12.BackgroundImage = null;
            pbxPc12.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc12.Text = "";
            pbxPc12.BackgroundImageLayout = ImageLayout.Center;
            
            //pbxPc13
            pbxPc13.BackgroundImage = null;
            pbxPc13.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc13.Text = "";
            pbxPc13.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc14
            pbxPc14.BackgroundImage = null;
            pbxPc14.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc14.Text = "";
            pbxPc14.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc15
            pbxPc15.BackgroundImage = null;
            pbxPc15.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc15.Text = "";
            pbxPc15.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc16
            pbxPc16.BackgroundImage = null;
            pbxPc16.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc16.Text = "";
            pbxPc16.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc17
            pbxPc17.BackgroundImage = null;
            pbxPc17.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc17.Text = "";
            pbxPc17.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc18
            pbxPc18.BackgroundImage = null;
            pbxPc18.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc18.Text = "";
            pbxPc18.BackgroundImageLayout = ImageLayout.Center;
            
            //pbxPc19
            pbxPc19.BackgroundImage = null;
            pbxPc19.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc19.Text = "";
            pbxPc19.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc20
            pbxPc20.BackgroundImage = null;
            pbxPc20.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc20.Text = "";
            pbxPc20.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc21
            pbxPc21.BackgroundImage = null;
            pbxPc21.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc21.Text = "";
            pbxPc21.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc22
            pbxPc22.BackgroundImage = null;
            pbxPc22.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc22.Text = "";
            pbxPc22.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc23
            pbxPc23.BackgroundImage = null;
            pbxPc23.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc23.Text = "";
            pbxPc23.BackgroundImageLayout = ImageLayout.Center;

            //pbxPc24
            pbxPc24.BackgroundImage = null;
            pbxPc24.BackgroundImage = Image.FromFile(@"..\..\Imagens\plus32.png");
            lblNomePc24.Text = "";
            pbxPc24.BackgroundImageLayout = ImageLayout.Center;
        }

        private void pbxExcluir_Click(object sender, EventArgs e)
        {
            LaboratorioController laboratorioController = new LaboratorioController();

            if (laboratorioController.excluir(Convert.ToInt32(cbxLaboratorio.SelectedValue)))
            {
                MessageBox.Show("Laboratório excluído com sucesso");
            }
            listar();
        }

        

        #region Inserir Computadores

        private void pbxPc1_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 1;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(0).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(0).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }      

        private void pbxPc2_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc2.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 2;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(1).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(1).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc3_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc3.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 3;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(2).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(2).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc4_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc4.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 4;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(3).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(3).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc5_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc5.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 5;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(4).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(4).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc6_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc6.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 6;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(5).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(5).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc7_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc7.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 7;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(6).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(6).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc8_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc8.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 8;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(7).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(7).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc9_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc9.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 9;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(8).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(8).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc10_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc10.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 10;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(9).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(9).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc11_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc11.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 11;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(10).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(10).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc12_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc12.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 12;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(11).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(11).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc13_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc13.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 13;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(12).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(12).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc14_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc14.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 14;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(13).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(13).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc15_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc15.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 15;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(14).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(14).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc16_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc16.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 16;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(15).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(15).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc17_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc17.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 17;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(16).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(16).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc18_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc18.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 18;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(17).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(17).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc19_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc19.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 19;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(18).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(18).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc20_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc20.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 20;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(19).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(19).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc21_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc21.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 21;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(20).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(20).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc22_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc22.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 22;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(21).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(21).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc23_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc23.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 23;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(22).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(22).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        private void pbxPc24_MouseClick(object sender, MouseEventArgs e)
        {
            if (lblNomePc24.Text.Equals(""))
            {
                VariaveisGlobais.posicaoComputador = 24;
                VariaveisGlobais.laboratorio = Convert.ToInt32(cbxLaboratorio.SelectedValue);
                FRMInserirComputador frm = new FRMInserirComputador();
                frm.ShowDialog();
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    DialogResult resul = MessageBox.Show("Deseja excluir esse computador?", "Confirmação", MessageBoxButtons.YesNo);

                    if (resul == DialogResult.Yes)
                    {
                        ComputadorController computadorController = new ComputadorController();
                        computadorController.excluir(listaPc.ElementAt(23).idComputador);
                    }
                }
                else
                {
                    VariaveisGlobais.idObject = listaPc.ElementAt(23).idComputador;
                    FRMAlterarComputador frm = new FRMAlterarComputador();
                    frm.ShowDialog();
                }
            }
            listarComputadores();
        }

        #endregion        

        private void cbxLaboratorio_SelectedIndexChanged(object sender, EventArgs e)
        {

            limparComputadores();

            if (!cbxLaboratorio.SelectedValue.ToString().Equals("CMS.Domain.LaboratorioDTO"))
            {
                listarComputadores();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            VariaveisGlobais.idObject = Convert.ToInt32(cbxLaboratorio.SelectedValue);
            FRMAlterarLaboratorio frm = new FRMAlterarLaboratorio();
            frm.ShowDialog();
            listar();
        }
    }
}
