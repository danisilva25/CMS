﻿using CMS.Controllers;
using CMS.Domain;
using CMS.Models;
using CMS.Others;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.Views.Laboratorio
{
    public partial class FRMInserirComputador : Form
    {
        public FRMInserirComputador()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            ComputadorDTO computadorDto = new ComputadorDTO();
            computadorDto.nomeComputador = tbxNome.Text;
            computadorDto.posicaoComputador = VariaveisGlobais.posicaoComputador;
            computadorDto.laboratorio = new LaboratorioDTO(VariaveisGlobais.laboratorio, null);
            computadorDto.laboratorio.descricaoLaboratorio = "";

            ComputadorController computador = new ComputadorController();

            if (computador.salvarComputador(computadorDto))
            {
                MessageBox.Show("Dados inseridos com sucesso!");
                VariaveisGlobais.cadastrou = true;
                VariaveisGlobais.nomePc = tbxNome.Text;
            }
            else
            {
                MessageBox.Show("Erro ao inserir os dados!");
            }
            this.Dispose();
        }
    }
}
