﻿using CMS.Controllers;
using CMS.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.Views.Laboratorio
{
    public partial class FRMInserirLaboratorio : Form
    {
        public FRMInserirLaboratorio()
        {
            InitializeComponent();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            LaboratorioDTO laboratorioDto = new LaboratorioDTO();
            laboratorioDto.descricaoLaboratorio = tbxDescricao.Text;

            LaboratorioController laboratorioController = new LaboratorioController();

            MessageBox.Show(laboratorioController.salvarLaboratorio(laboratorioDto));
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }


        private void limparCampos()
        {
            tbxDescricao.Text = "";
        }
    }
}
