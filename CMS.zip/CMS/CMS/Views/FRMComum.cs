﻿using CMS.Others;
using CMS.Views;
using CMS.Views.DesligarComputador;
using CMS.Views.Laboratorio;
using CMS.Views.Relatar_Problema;
using CMS.Views.Usuario;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS
{
    public partial class FRMComum : Form
    {
        public FRMComum()
        {
            InitializeComponent();

            Screen screen = Screen.FromControl(this);

            Rectangle workingArea = screen.WorkingArea;
            this.Location = new Point()
            {
                X = Math.Max(workingArea.X, workingArea.X + (workingArea.Width - this.Width) / 2),
                Y = -110
            };

            if (VariaveisGlobais.usuario == null)
                pbxAlterarSenha.Enabled = false;
        }

        private void FRMAdmin_MouseMove(object sender, MouseEventArgs e)
        {
            Screen screen = Screen.FromControl(this);

            Rectangle workingArea = screen.WorkingArea;
            this.Location = new Point()
            {
                X = Math.Max(workingArea.X, workingArea.X + (workingArea.Width - this.Width) / 2),
                Y = 0
            };

            tmrTela.Enabled = true;
        }

        private void tmrTela_Tick(object sender, EventArgs e)
        {
            Screen screen = Screen.FromControl(this);

            Rectangle workingArea = screen.WorkingArea;
            this.Location = new Point()
            {
                X = Math.Max(workingArea.X, workingArea.X + (workingArea.Width - this.Width) / 2),
                Y = -110
            };

            tmrTela.Enabled = false;
        }

        private void pbxDesligar_Click(object sender, EventArgs e)
        {
            FRMDesligarComputador frm = new FRMDesligarComputador();
            frm.ShowDialog();
        }

        private void pbxRelatarProblema_Click(object sender, EventArgs e)
        {
            FRMRelatarProblema frm = new FRMRelatarProblema();
            frm.ShowDialog();
        }

        private void FRMComum_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = e.CloseReason == CloseReason.UserClosing;
        }

        private void pbxAlterarSenha_Click(object sender, EventArgs e)
        {
            FRMAlterarSenha frm = new FRMAlterarSenha();
            frm.Show();
        }
    }
}
