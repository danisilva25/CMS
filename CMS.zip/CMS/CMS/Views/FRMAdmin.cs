﻿using CMS.Others;
using CMS.Views;
using CMS.Views.Acesso;
using CMS.Views.DesligarComputador;
using CMS.Views.Email;
using CMS.Views.Laboratorio;
using CMS.Views.Usuario;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS
{
    public partial class FRMAdmin : Form
    {
        public FRMAdmin()
        {
            InitializeComponent();

            Screen screen = Screen.FromControl(this);

            Rectangle workingArea = screen.WorkingArea;
            this.Location = new Point()
            {
                X = Math.Max(workingArea.X, workingArea.X + (workingArea.Width - this.Width) / 2),
                Y = -110
            };

            if (VariaveisGlobais.usuario == null)
                pbxSenha.Enabled = false;
        }

        private void btnCadastrousuario_Click(object sender, EventArgs e)
        {
            FRMUsuario frm = new FRMUsuario();
            frm.Show();
        }

        private void btnLaboratorio_Click(object sender, EventArgs e)
        {
            FRMLaboratorio frm = new FRMLaboratorio();
            frm.Show();
        }
        private void FRMAdmin_MouseMove(object sender, MouseEventArgs e)
        {
            Screen screen = Screen.FromControl(this);

            Rectangle workingArea = screen.WorkingArea;
            this.Location = new Point()
            {
                X = Math.Max(workingArea.X, workingArea.X + (workingArea.Width - this.Width) / 2),
                Y = 0
            };

            tmrTela.Enabled = true;
        }

        private void tmrTela_Tick(object sender, EventArgs e)
        {
            Screen screen = Screen.FromControl(this);

            Rectangle workingArea = screen.WorkingArea;
            this.Location = new Point()
            {
                X = Math.Max(workingArea.X, workingArea.X + (workingArea.Width - this.Width) / 2),
                Y = -110
            };

            tmrTela.Enabled = false;
        }

        private void pbxUsuario_Click(object sender, EventArgs e)
        {
            FRMUsuario frm = new FRMUsuario();
            frm.ShowDialog();
        }

        private void pbxLaboratorio_Click(object sender, EventArgs e)
        {
            FRMLaboratorio frm = new FRMLaboratorio();
            frm.ShowDialog();
        }

        private void pbxDesligar_Click(object sender, EventArgs e)
        {
            FRMDesligarComputador frm = new FRMDesligarComputador();
            frm.ShowDialog();
        }

        private void pbxAcesso_Click(object sender, EventArgs e)
        {
            FRMAcesso frm = new FRMAcesso();
            frm.ShowDialog();
        }

        private void FRMAdmin_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = e.CloseReason == CloseReason.UserClosing;
        }

        private void pbxEmail_Click(object sender, EventArgs e)
        {
            FRMEmail frm = new FRMEmail();
            frm.ShowDialog();
        }

        private void pbxSenha_Click(object sender, EventArgs e)
        {
            FRMAlterarSenha frm = new FRMAlterarSenha();
            frm.Show();
        }
    }
}
