﻿using CMS.Controllers;
using CMS.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.Views.Email
{
    public partial class FRMEmail : Form
    {
        public FRMEmail()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            EmailDTO email = new EmailDTO();
            EmailController emailController = new EmailController();

            email.emailAdmin = tbxEmail.Text;

            MessageBox.Show(emailController.salvar(email));
        }
    }
}
