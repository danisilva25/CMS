﻿namespace CMS.Views.Relatar_Problema
{
    partial class FRMRelatarProblema
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRMRelatarProblema));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.cbxOutros = new System.Windows.Forms.CheckBox();
            this.tbxObservação = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbxTeclado = new System.Windows.Forms.CheckBox();
            this.cbxTela = new System.Windows.Forms.CheckBox();
            this.cbxOutroComputador = new System.Windows.Forms.CheckBox();
            this.cbxMouse = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnCancelar);
            this.groupBox1.Controls.Add(this.btnEnviar);
            this.groupBox1.Controls.Add(this.cbxOutros);
            this.groupBox1.Controls.Add(this.tbxObservação);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cbxTeclado);
            this.groupBox1.Controls.Add(this.cbxTela);
            this.groupBox1.Controls.Add(this.cbxOutroComputador);
            this.groupBox1.Controls.Add(this.cbxMouse);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(654, 429);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Relatar Problema";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancelar.Location = new System.Drawing.Point(548, 133);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(87, 88);
            this.btnCancelar.TabIndex = 9;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnEnviar
            // 
            this.btnEnviar.Image = ((System.Drawing.Image)(resources.GetObject("btnEnviar.Image")));
            this.btnEnviar.Location = new System.Drawing.Point(548, 23);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(87, 88);
            this.btnEnviar.TabIndex = 8;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEnviar.UseVisualStyleBackColor = true;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // cbxOutros
            // 
            this.cbxOutros.AutoSize = true;
            this.cbxOutros.Location = new System.Drawing.Point(16, 161);
            this.cbxOutros.Name = "cbxOutros";
            this.cbxOutros.Size = new System.Drawing.Size(57, 17);
            this.cbxOutros.TabIndex = 7;
            this.cbxOutros.Text = "Outros";
            this.cbxOutros.UseVisualStyleBackColor = true;
            // 
            // tbxObservação
            // 
            this.tbxObservação.BackColor = System.Drawing.SystemColors.MenuBar;
            this.tbxObservação.Location = new System.Drawing.Point(16, 227);
            this.tbxObservação.Multiline = true;
            this.tbxObservação.Name = "tbxObservação";
            this.tbxObservação.Size = new System.Drawing.Size(619, 183);
            this.tbxObservação.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(298, 202);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Observações";
            // 
            // cbxTeclado
            // 
            this.cbxTeclado.AutoSize = true;
            this.cbxTeclado.Location = new System.Drawing.Point(16, 105);
            this.cbxTeclado.Name = "cbxTeclado";
            this.cbxTeclado.Size = new System.Drawing.Size(132, 17);
            this.cbxTeclado.TabIndex = 4;
            this.cbxTeclado.Text = "Problemas no Teclado";
            this.cbxTeclado.UseVisualStyleBackColor = true;
            // 
            // cbxTela
            // 
            this.cbxTela.AutoSize = true;
            this.cbxTela.Location = new System.Drawing.Point(292, 51);
            this.cbxTela.Name = "cbxTela";
            this.cbxTela.Size = new System.Drawing.Size(114, 17);
            this.cbxTela.TabIndex = 3;
            this.cbxTela.Text = "Problemas na Tela";
            this.cbxTela.UseVisualStyleBackColor = true;
            // 
            // cbxOutroComputador
            // 
            this.cbxOutroComputador.AutoSize = true;
            this.cbxOutroComputador.Location = new System.Drawing.Point(292, 105);
            this.cbxOutroComputador.Name = "cbxOutroComputador";
            this.cbxOutroComputador.Size = new System.Drawing.Size(178, 17);
            this.cbxOutroComputador.TabIndex = 2;
            this.cbxOutroComputador.Text = "Problemas em outro computador";
            this.cbxOutroComputador.UseVisualStyleBackColor = true;
            // 
            // cbxMouse
            // 
            this.cbxMouse.AutoSize = true;
            this.cbxMouse.Location = new System.Drawing.Point(16, 51);
            this.cbxMouse.Name = "cbxMouse";
            this.cbxMouse.Size = new System.Drawing.Size(125, 17);
            this.cbxMouse.TabIndex = 0;
            this.cbxMouse.Text = "Problemas no Mouse";
            this.cbxMouse.UseVisualStyleBackColor = true;
            // 
            // FRMRelatarProblema
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(678, 462);
            this.Controls.Add(this.groupBox1);
            this.Name = "FRMRelatarProblema";
            this.Text = "FRMRelatarProblema";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cbxTeclado;
        private System.Windows.Forms.CheckBox cbxTela;
        private System.Windows.Forms.CheckBox cbxMouse;
        private System.Windows.Forms.TextBox tbxObservação;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbxOutros;
        private System.Windows.Forms.CheckBox cbxOutroComputador;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnEnviar;
    }
}