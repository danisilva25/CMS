﻿using CMS.Controllers;
using CMS.Domain;
using CMS.Others;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS.Views.Relatar_Problema
{
    public partial class FRMRelatarProblema : Form
    {
        UsuarioDTO usuario = (UsuarioDTO)Convert.ChangeType(VariaveisGlobais.usuario, typeof(UsuarioDTO));
        ComputadorDTO pc = (ComputadorDTO)Convert.ChangeType(VariaveisGlobais.computador, typeof(ComputadorDTO));

        private String text;

        public FRMRelatarProblema()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            problemas();

            try
            {
                EmailController controller = new EmailController();

                MailMessage mail = new MailMessage();
                mail.From = new MailAddress("computermanagementsystemcms@outlook.com", "CMS", System.Text.Encoding.UTF8);
                mail.To.Add(new MailAddress(controller.retornaEmail()));
                mail.Subject = "Problemas relatados";
                mail.SubjectEncoding = System.Text.Encoding.UTF8;
                mail.Body = text;
                mail.IsBodyHtml = true;
                mail.Priority = MailPriority.High;

                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp-mail.outlook.com";
                smtp.Port = 587;
                smtp.EnableSsl = true;
                smtp.Credentials = new NetworkCredential("computermanagementsystemcms@outlook.com", "[(cms%&@managementsystem)]");              
                smtp.Send(mail);

                MessageBox.Show("Email enviado com sucesso");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro ao enviar email! Erro: " + ex.Message);
            }
            
        }

        private void problemas()
        {
            text = "O usuário " + usuario.nomeUsuario + " no computador " + pc.nomeComputador + ", no laboratório " + pc.laboratorio.descricaoLaboratorio + " na posição " + pc.posicaoComputador +" reportou os seguintes problemas: <br/><br/><br/>";

            if (cbxMouse.Checked)
                text += "Um problema no mouse<br/>";
            if (cbxTeclado.Checked)
                text += "Um problema no teclado<br/>";
            if (cbxTela.Checked)
                text += "Um problema na tela<br/>";
            if (cbxOutroComputador.Checked)
                text += "Problemas em outro computador<br/>";
            if (cbxOutros.Checked)
                text += "Um outro problema";

            text += "<br/><br/>Observações: " + tbxObservação.Text;
        }
    }
}
