﻿namespace CMS
{
    partial class FRMAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRMAdmin));
            this.pbxUsuario = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pbxLaboratorio = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pbxAcesso = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pbxDesligar = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tmrTela = new System.Windows.Forms.Timer(this.components);
            this.pbxSenha = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pbxEmail = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUsuario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLaboratorio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAcesso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDesligar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSenha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEmail)).BeginInit();
            this.SuspendLayout();
            // 
            // pbxUsuario
            // 
            this.pbxUsuario.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxUsuario.BackgroundImage")));
            this.pbxUsuario.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbxUsuario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxUsuario.Location = new System.Drawing.Point(161, 16);
            this.pbxUsuario.Name = "pbxUsuario";
            this.pbxUsuario.Size = new System.Drawing.Size(79, 73);
            this.pbxUsuario.TabIndex = 2;
            this.pbxUsuario.TabStop = false;
            this.pbxUsuario.Click += new System.EventHandler(this.pbxUsuario_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(179, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Usuário";
            // 
            // pbxLaboratorio
            // 
            this.pbxLaboratorio.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxLaboratorio.BackgroundImage")));
            this.pbxLaboratorio.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbxLaboratorio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxLaboratorio.Location = new System.Drawing.Point(257, 16);
            this.pbxLaboratorio.Name = "pbxLaboratorio";
            this.pbxLaboratorio.Size = new System.Drawing.Size(79, 73);
            this.pbxLaboratorio.TabIndex = 4;
            this.pbxLaboratorio.TabStop = false;
            this.pbxLaboratorio.Click += new System.EventHandler(this.pbxLaboratorio_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(267, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Laboratório";
            // 
            // pbxAcesso
            // 
            this.pbxAcesso.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxAcesso.BackgroundImage")));
            this.pbxAcesso.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbxAcesso.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxAcesso.Location = new System.Drawing.Point(351, 16);
            this.pbxAcesso.Name = "pbxAcesso";
            this.pbxAcesso.Size = new System.Drawing.Size(79, 73);
            this.pbxAcesso.TabIndex = 6;
            this.pbxAcesso.TabStop = false;
            this.pbxAcesso.Click += new System.EventHandler(this.pbxAcesso_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(371, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Acesso";
            // 
            // pbxDesligar
            // 
            this.pbxDesligar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxDesligar.BackgroundImage")));
            this.pbxDesligar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbxDesligar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxDesligar.Location = new System.Drawing.Point(634, 16);
            this.pbxDesligar.Name = "pbxDesligar";
            this.pbxDesligar.Size = new System.Drawing.Size(79, 73);
            this.pbxDesligar.TabIndex = 8;
            this.pbxDesligar.TabStop = false;
            this.pbxDesligar.Click += new System.EventHandler(this.pbxDesligar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(652, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Desligar";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Humnst777 Blk BT", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 49);
            this.label5.TabIndex = 10;
            this.label5.Text = "CMS";
            // 
            // tmrTela
            // 
            this.tmrTela.Interval = 10000;
            this.tmrTela.Tick += new System.EventHandler(this.tmrTela_Tick);
            // 
            // pbxSenha
            // 
            this.pbxSenha.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxSenha.BackgroundImage")));
            this.pbxSenha.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbxSenha.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxSenha.Location = new System.Drawing.Point(446, 16);
            this.pbxSenha.Name = "pbxSenha";
            this.pbxSenha.Size = new System.Drawing.Size(79, 73);
            this.pbxSenha.TabIndex = 11;
            this.pbxSenha.TabStop = false;
            this.pbxSenha.Click += new System.EventHandler(this.pbxSenha_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(451, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Alterar Senha";
            // 
            // pbxEmail
            // 
            this.pbxEmail.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxEmail.BackgroundImage")));
            this.pbxEmail.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbxEmail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxEmail.Location = new System.Drawing.Point(540, 16);
            this.pbxEmail.Name = "pbxEmail";
            this.pbxEmail.Size = new System.Drawing.Size(79, 73);
            this.pbxEmail.TabIndex = 13;
            this.pbxEmail.TabStop = false;
            this.pbxEmail.Click += new System.EventHandler(this.pbxEmail_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(550, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Alterar Email";
            // 
            // FRMAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(722, 114);
            this.ControlBox = false;
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pbxEmail);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pbxSenha);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pbxDesligar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pbxAcesso);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pbxLaboratorio);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbxUsuario);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FRMAdmin";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FRMAdmin_FormClosing);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.FRMAdmin_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.pbxUsuario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLaboratorio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAcesso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDesligar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSenha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEmail)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbxUsuario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbxLaboratorio;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbxAcesso;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbxDesligar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Timer tmrTela;
        private System.Windows.Forms.PictureBox pbxSenha;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pbxEmail;
        private System.Windows.Forms.Label label7;
    }
}

