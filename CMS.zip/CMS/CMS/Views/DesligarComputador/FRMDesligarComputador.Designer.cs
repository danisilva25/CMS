﻿namespace CMS.Views.DesligarComputador
{
    partial class FRMDesligarComputador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRMDesligarComputador));
            this.btnDesligarComputador = new System.Windows.Forms.Button();
            this.btnReiniciarComputador = new System.Windows.Forms.Button();
            this.btnLogoff = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnDesligarComputador
            // 
            this.btnDesligarComputador.Image = ((System.Drawing.Image)(resources.GetObject("btnDesligarComputador.Image")));
            this.btnDesligarComputador.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDesligarComputador.Location = new System.Drawing.Point(12, 30);
            this.btnDesligarComputador.Name = "btnDesligarComputador";
            this.btnDesligarComputador.Size = new System.Drawing.Size(85, 90);
            this.btnDesligarComputador.TabIndex = 0;
            this.btnDesligarComputador.Text = "Desligar";
            this.btnDesligarComputador.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDesligarComputador.UseVisualStyleBackColor = true;
            this.btnDesligarComputador.Click += new System.EventHandler(this.btnDesligarComputador_Click);
            // 
            // btnReiniciarComputador
            // 
            this.btnReiniciarComputador.Image = ((System.Drawing.Image)(resources.GetObject("btnReiniciarComputador.Image")));
            this.btnReiniciarComputador.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnReiniciarComputador.Location = new System.Drawing.Point(113, 30);
            this.btnReiniciarComputador.Name = "btnReiniciarComputador";
            this.btnReiniciarComputador.Size = new System.Drawing.Size(85, 90);
            this.btnReiniciarComputador.TabIndex = 1;
            this.btnReiniciarComputador.Text = "Reiniciar";
            this.btnReiniciarComputador.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnReiniciarComputador.UseVisualStyleBackColor = true;
            this.btnReiniciarComputador.Click += new System.EventHandler(this.btnReiniciarComputador_Click);
            // 
            // btnLogoff
            // 
            this.btnLogoff.Image = ((System.Drawing.Image)(resources.GetObject("btnLogoff.Image")));
            this.btnLogoff.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnLogoff.Location = new System.Drawing.Point(215, 30);
            this.btnLogoff.Name = "btnLogoff";
            this.btnLogoff.Size = new System.Drawing.Size(85, 90);
            this.btnLogoff.TabIndex = 2;
            this.btnLogoff.Text = "Logoff";
            this.btnLogoff.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnLogoff.UseVisualStyleBackColor = true;
            this.btnLogoff.Click += new System.EventHandler(this.btnLogoff_Click);
            // 
            // btnSair
            // 
            this.btnSair.Image = ((System.Drawing.Image)(resources.GetObject("btnSair.Image")));
            this.btnSair.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSair.Location = new System.Drawing.Point(317, 30);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(85, 90);
            this.btnSair.TabIndex = 3;
            this.btnSair.Text = "Sair";
            this.btnSair.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // FRMDesligarComputador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(409, 147);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLogoff);
            this.Controls.Add(this.btnReiniciarComputador);
            this.Controls.Add(this.btnDesligarComputador);
            this.Name = "FRMDesligarComputador";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Desligar Computador";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnDesligarComputador;
        private System.Windows.Forms.Button btnReiniciarComputador;
        private System.Windows.Forms.Button btnLogoff;
        private System.Windows.Forms.Button btnSair;
    }
}