﻿using CMS.Domain;
using CMS.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Models
{
    public class Usuario
    {
        public Usuario() { }

        public Boolean salvarUsuario(UsuarioDTO usuarioDto)
        {
            try
            {
                UsuarioDAO usuarioDao = new UsuarioDAO();
                return usuarioDao.salvar(usuarioDto);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao salvar usuário! Erro: " + ex.Message);
                return false;
            }
        }
        public List<UsuarioDTO> listarUsuario(String buscar)
        {
            try
            {
                UsuarioDAO usuarioDao = new UsuarioDAO();

                return usuarioDao.listar(buscar);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao listar usuários! Erro: " + ex.Message);
                return null;
            }
        }
        public UsuarioDTO carregarUsuario(int idUsuario)
        {
            try
            {
                UsuarioDAO usuarioDao = new UsuarioDAO();
                return usuarioDao.carregar(idUsuario);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao carregar usuário! Erro: " + ex.Message);
                return null;
            }
        }
        public Boolean excluirUsuario(int idUsuario)
        {
            try
            {
                UsuarioDAO usuarioDao = new UsuarioDAO();
                return usuarioDao.excluir(idUsuario);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao excluir usuário! Erro: " + ex.Message);
                return false;
            }
        }
        public UsuarioDTO logar(String matricula, String senha)
        {
            try
            {
                UsuarioDAO usuarioDao = new UsuarioDAO();
                return usuarioDao.logar(matricula, senha);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Erro na model ao logar Usuário! Erro: " + ex.Message);
                return null;
            }
        }
        public Boolean alterarSenha(String senhaAtual, String novaSenha, int idUsuario)
        {
            try
            {
                UsuarioDAO usuarioDao = new UsuarioDAO();
                return usuarioDao.alterarSenha(senhaAtual, novaSenha, idUsuario);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao alterar senha! Erro: " + ex.Message);
                return false;
            }
        }
    }
}
