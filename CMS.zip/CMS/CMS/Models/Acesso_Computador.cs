﻿using CMS.Domain;
using CMS.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Models
{
    class Acesso_Computador
    {
        public bool gravar(Acesso_ComputadorDTO acesso_computadorDto)
        {
            try
            {
                Acesso_ComputadorDAO acesso_ComputadorDao = new Acesso_ComputadorDAO();
                return acesso_ComputadorDao.salvar(acesso_computadorDto);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao gravar acesso! Erro: " + ex.Message);
                return false;
            }
        }
        public List<Acesso_ComputadorDTO> listar(DateTime data, int laboratorio)
        {
            try
            {
                Acesso_ComputadorDAO acessoDao = new Acesso_ComputadorDAO();
                return acessoDao.listar(data, laboratorio);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao listar acesso! Erro: " + ex.Message);
                return null;
            }
        }
        public bool excluir(DateTime? data, int posicao)
        {
            try
            {
                Acesso_ComputadorDAO acessoDao = new Acesso_ComputadorDAO();
                return acessoDao.excluir(data, posicao);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao excluir acessos! Erro: " + ex.Message);
                return false;
            }
        }
    }
}
