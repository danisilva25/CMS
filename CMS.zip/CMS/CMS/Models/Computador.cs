﻿using CMS.Domain;
using CMS.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Models
{
    class Computador
    {
        public Boolean salvar(ComputadorDTO computadorDto)
        {
            try
            {
                ComputadorDAO computadorDao = new ComputadorDAO();
                return computadorDao.salvar(computadorDto);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na Model ao salvar Computador! Erro: " + ex.Message);
                return false;
            }
        }
        public List<ComputadorDTO> listar(string buscar)
        {
            try
            {
                ComputadorDAO computadorDao = new ComputadorDAO();
                return computadorDao.listar(buscar);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao listar computador! Erro: " + ex.Message);
                return null;
            }
        }
        public ComputadorDTO carregar(int id)
        {
            try
            {
                ComputadorDAO computadorDao = new ComputadorDAO();
                return computadorDao.carregar(id);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao listar computador! Erro: " + ex.Message);
                return null;
            }
        }
        public Boolean excluir(int id)
        {
            try
            {
                ComputadorDAO computadorDao = new ComputadorDAO();
                return computadorDao.excluir(id);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao listar computador! Erro: " + ex.Message);
                return false;
            }
        }

        public ComputadorDTO carregarPorNome(String nome)
        {
            try
            {
                ComputadorDAO computadorDao = new ComputadorDAO();
                return computadorDao.carregarPorNome(nome);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao listar computador! Erro: " + ex.Message);
                return null;
            }
        }
    }
}
