﻿using CMS.Domain;
using CMS.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace CMS.Models
{
    class Laboratorio
    {
        public Boolean salvar(LaboratorioDTO laboratorio)
        {
            try
            {
                LaboratorioDAO laboratorioDAO = new LaboratorioDAO();
                return laboratorioDAO.salvar(laboratorio);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao salvar usuario! Erro: " + ex.Message);
                return false;
            }
        }

        public List<LaboratorioDTO> listar(String busca)
        {
            try
            {
                LaboratorioDAO laboratorioDAO = new LaboratorioDAO();
                return laboratorioDAO.listar(busca);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao salvar usuario! Erro: " + ex.Message);
                return null;
            }
        }

        public LaboratorioDTO carregar(int id)
        {
            try
            {
                LaboratorioDAO laboratorioDAO = new LaboratorioDAO();
                return laboratorioDAO.carregar(id);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao salvar usuario! Erro: " + ex.Message);
                return null;
            }
        }

        public Boolean excluir(int id)
        {
            try
            {
                LaboratorioDAO laboratorioDAO = new LaboratorioDAO();
                return laboratorioDAO.excluir(id);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao salvar usuario! Erro: " + ex.Message);
                return false;
            }
        }
    }
}
