﻿using CMS.Domain;
using CMS.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Models
{
    public class Email
    {
        public bool salvarEmail(EmailDTO email)
        {
            try
            {
                EmailDAO emailDao = new EmailDAO();
                return emailDao.trocarEmail(email);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao salvar email! Erro: " + ex.Message);
                return false;
            }
        }
        public String retornaEmail(EmailDTO email)
        {
            try
            {
                EmailDAO emailDao = new EmailDAO();
                return emailDao.retornaEmail();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na model ao retornar email! Erro: " + ex.Message);
                return null;
            }
        }
    }
}
