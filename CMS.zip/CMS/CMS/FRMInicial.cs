﻿using CMS.Controllers;
using CMS.Domain;
using CMS.Others;
using CMS.Views.DesligarComputador;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Diagnostics;
using Microsoft.Win32;

namespace CMS
{
    public partial class FRMInicial : Form
    {
        UsuarioDTO usuarioDto = null;

        public FRMInicial()
        {
            InitializeComponent();           
        }

        private void pbxDesligar_Click(object sender, EventArgs e)
        {
            FRMDesligarComputador frm = new FRMDesligarComputador();
            frm.ShowDialog();
        }

        private void abrirTelaComum()
        {
            VariaveisGlobais.usuario = usuarioDto;
            this.Hide();
            FRMComum frm = new FRMComum();
            frm.Closed += (s, args) => this.Dispose();
            frm.Show();
        }

        private void abrirTelaAdmin()
        {
            VariaveisGlobais.usuario = usuarioDto;
            this.Hide();
            FRMAdmin frm = new FRMAdmin();
            frm.Closed += (s, args) => this.Dispose();
            frm.Show();
        }

        private void btnLogar_Click(object sender, EventArgs e)
        {
            try
            {
                String login = tbxMatricula.Text;
                String senha = tbxSenha.Text;

                UsuarioController usuarioController = new UsuarioController();
                usuarioDto = usuarioController.logar(login, senha);
                ComputadorController pcController = new ComputadorController();
                Acesso_ComputadorController acessoPc = new Acesso_ComputadorController();
                String nomePc = Environment.MachineName;
                ComputadorDTO pc = pcController.carregarPorNome(nomePc);
                VariaveisGlobais.computador = pc;
                VariaveisGlobais.usuario = usuarioDto;

                if (login.Equals("486231597") && senha.Equals("(Computer)!@#(Management)!@#(System)"))
                {
                    abrirTelaAdmin();
                    ShowStartMenu();
                }
                else if (login.Equals("315974862") && senha.Equals("([Computer@Management@System])"))
                {
                    abrirTelaComum();
                    ShowStartMenu();
                }
                else
                {
                    if (usuarioDto == null)
                    {
                        MessageBox.Show("Login e/ou senha incorretos");
                    }
                    else
                    {
                        if (pc != null)
                        {
                            LaboratorioDTO labDto = new LaboratorioDTO();
                            labDto.idLaboratorio = pc.laboratorio.idLaboratorio;
                            labDto.descricaoLaboratorio = pc.laboratorio.descricaoLaboratorio;

                            Acesso_ComputadorDTO acessoDto = new Acesso_ComputadorDTO();
                            acessoDto.computador = pc;
                            acessoDto.usuario = usuarioDto;
                            acessoDto.dataAcesso = DateTime.Now;
                            acessoDto.laboratorio = labDto;

                            if (acessoPc.gravar(acessoDto))
                            {
                                if (usuarioDto.permissaoUsuario == 0)
                                {
                                    ShowStartMenu();
                                    abrirTelaComum();
                                }
                                else
                                {
                                    ShowStartMenu();
                                    EnableGerenciadorTarefas();
                                    abrirTelaAdmin();
                                }
                            }
                        }
                    }
                } 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro na view ao fazer login! Erro: " + ex.Message);
            }          
        }

        private void tbxMatricula_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar) || char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void FRMInicial_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = e.CloseReason == CloseReason.UserClosing;
        }


        #region bloqueia teclas

        public void KillGerenciadorTarefas()
        {
            RegistryKey regkey;
            string keyValueInt = "1";
            string subKey = @"Software\Microsoft\Windows\CurrentVersion\Policies\System";

            try
            {
                regkey = Registry.CurrentUser.CreateSubKey(subKey);
                regkey.SetValue("DisableTaskMgr", keyValueInt);
                regkey.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        } 
        
        [DllImport("user32", EntryPoint = "SetWindowsHookExA", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        public static extern int SetWindowsHookEx(int idHook, LowLevelKeyboardProcDelegate lpfn, int hMod, int dwThreadId);
        [DllImport("user32", EntryPoint = "UnhookWindowsHookEx", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        public static extern int UnhookWindowsHookEx(int hHook);
        public delegate int LowLevelKeyboardProcDelegate(int nCode, int wParam, ref KBDLLHOOKSTRUCT lParam);
        [DllImport("user32", EntryPoint = "CallNextHookEx", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        public static extern int CallNextHookEx(int hHook, int nCode, int wParam, ref KBDLLHOOKSTRUCT lParam);
        public const int WH_KEYBOARD_LL = 13;

        /*code needed to disable start menu*/
        [DllImport("user32.dll")]
        private static extern int FindWindow(string className, string windowText);
        [DllImport("user32.dll")]
        private static extern int ShowWindow(int hwnd, int command);

        private const int SW_HIDE = 0;
        private const int SW_SHOW = 1;

        public struct KBDLLHOOKSTRUCT
        {
            public int vkCode;
            public int scanCode;
            public int flags;
            public int time;
            public int dwExtraInfo;
        }
        public static int intLLKey;

        public int LowLevelKeyboardProc(int nCode, int wParam, ref KBDLLHOOKSTRUCT lParam)
        {
            bool blnEat = false;

            switch (wParam)
            {
                case 256:
                case 257:
                case 260:
                case 261:
                    //Alt+Tab, Alt+Esc, Ctrl+Esc, Windows Key,
                    blnEat = ((lParam.vkCode == 9) && (lParam.flags == 32)) | ((lParam.vkCode == 27) && (lParam.flags == 32)) | ((lParam.vkCode == 27) && (lParam.flags == 0)) | ((lParam.vkCode == 91) && (lParam.flags == 1)) | ((lParam.vkCode == 92) && (lParam.flags == 1)) | ((lParam.vkCode == 73) && (lParam.flags == 0));
                    break;
            }

            if (blnEat == true)
            {
                return 1;
            }
            else
            {
                return CallNextHookEx(0, nCode, wParam, ref lParam);
            }
        }
        public void KillStartMenu()
        {
            int hwnd = FindWindow("Shell_TrayWnd", "");
            ShowWindow(hwnd, SW_HIDE);
        }

        private void FRMInicial_Load(object sender, EventArgs e)
        {
            intLLKey = SetWindowsHookEx(WH_KEYBOARD_LL, LowLevelKeyboardProc, System.Runtime.InteropServices.Marshal.GetHINSTANCE(System.Reflection.Assembly.GetExecutingAssembly().GetModules()[0]).ToInt32(), 0);
            KillGerenciadorTarefas();
            KillStartMenu();
        }

        public static void ShowStartMenu()
        {
            int hwnd = FindWindow("Shell_TrayWnd", "");
            ShowWindow(hwnd, SW_SHOW);
        }

        public static void EnableGerenciadorTarefas()
        {
            try
            {
                string subKey = @"Software\Microsoft\Windows\CurrentVersion\Policies\System";
                RegistryKey rk = Registry.CurrentUser;
                RegistryKey sk1 = rk.OpenSubKey(subKey);
                if (sk1 != null)
                    rk.DeleteSubKeyTree(subKey);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        #endregion
    }
}