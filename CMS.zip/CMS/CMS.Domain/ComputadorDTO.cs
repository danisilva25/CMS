﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Domain
{
    public class ComputadorDTO
    {
        public ComputadorDTO() { }

        public ComputadorDTO(String nome, int posicao)
        {
            this.nomeComputador = nome;
            this.posicaoComputador = posicao;
        }

        public int idComputador { get; set; }
        public int posicaoComputador { get; set; }
        public String nomeComputador { get; set; }
        public LaboratorioDTO laboratorio { get; set; }
    }
}
