﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Domain
{
    public class EmailDTO
    {
        public int idEmail { get; set; }
        public String emailAdmin { get; set; }
    }
}
