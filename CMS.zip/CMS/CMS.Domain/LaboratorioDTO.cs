﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Domain
{
    public class LaboratorioDTO
    {
        public LaboratorioDTO() { }

        public LaboratorioDTO(int id, string descricao)
        {
            this.idLaboratorio = id;
            this.descricaoLaboratorio = descricao;
        }

        public LaboratorioDTO(string descricao)
        {
            this.descricaoLaboratorio = descricao;
        }

        public int idLaboratorio { get; set; }
        public String descricaoLaboratorio { get; set; }
    }
}
