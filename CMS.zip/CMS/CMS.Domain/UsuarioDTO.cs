﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Domain
{
    public class UsuarioDTO
    {
        public UsuarioDTO() { }
        public UsuarioDTO(String matriculaUsuario, String nomeUsuario)
        {
            this.matriculaUsuario = matriculaUsuario;
            this.nomeUsuario = nomeUsuario;
        }

        public int idUsuario { get; set; }
        public String nomeUsuario { get; set; }
        public String matriculaUsuario { get; set; }
        public String senhaUsuario { get; set; }
        public int permissaoUsuario { get; set; }
        public String salt { get; set; }
    }
}
