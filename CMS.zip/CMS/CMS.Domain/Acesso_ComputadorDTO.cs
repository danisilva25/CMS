﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Domain
{
    public class Acesso_ComputadorDTO
    {
        public int idAcesso { get; set; }
        public ComputadorDTO computador { get; set; }
        public LaboratorioDTO laboratorio { get; set; }
        public UsuarioDTO usuario { get; set; }
        public DateTime dataAcesso { get; set; }
    }
}
