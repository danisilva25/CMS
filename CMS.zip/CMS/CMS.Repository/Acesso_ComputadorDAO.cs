﻿using CMS.Domain;
using CMS.Others;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Repository
{
    public class Acesso_ComputadorDAO
    {
        Conexao conn = new Conexao();
        
        public bool salvar(Acesso_ComputadorDTO obj)
        {
            try
            {
                conn.openConnection();
                conn.openConnection().BeginTransaction();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                cmd.CommandText = "insert into acesso_computador(idComputador, idLaboratorio, idUsuario, "
                    + "date) values (@computador, @laboratorio, @usuario, @data)";
                cmd.Parameters.AddWithValue("@computador", obj.computador.idComputador);
                cmd.Parameters.AddWithValue("@laboratorio", obj.laboratorio.idLaboratorio);
                cmd.Parameters.AddWithValue("@usuario", obj.usuario.idUsuario);
                cmd.Parameters.AddWithValue("@data", DateTime.Now);

                cmd.ExecuteNonQuery();
                conn.openConnection().BeginTransaction().Commit();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao inserir acesso! Erro: " + ex.Message);
                conn.openConnection().BeginTransaction().Rollback();
                return false;
            }
            finally
            {
                try
                {                    
                    conn.closeConnection();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro ao fechar os parâmetros de conexão na dao Acesso_Computador! Erro: " + ex.Message);
                }
            }
        }

        public List<Acesso_ComputadorDTO> listar(DateTime data, int laboratorio)
        {
            List<Acesso_ComputadorDTO> listaAcesso = new List<Acesso_ComputadorDTO>();
            Acesso_ComputadorDTO acessoDto = null;
            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                cmd.CommandText = "select CONVERT(CHAR, a.date, 24) as 'date', l.descricaoLaboratorio, " +
                "u.matriculaUsuario, u.nomeUsuario, c.nomeComputador, c.posicaoComputador from acesso_computador a " +
                "inner join laboratorio l on l.idLaboratorio = a.idLaboratorio " +
                "inner join usuario u on u.idUsuario = a.idUsuario " +
                "inner join computador c on c.idComputador = a.idComputador " +  
                "where a.idLaboratorio = @lab and CONVERT(char, a.date, 103) = '" + data.ToString("dd/MM/yyyy") + "';";
                cmd.Parameters.AddWithValue("@lab", laboratorio);
                var resul = cmd.ExecuteReader();

                while(resul.Read())
                {
                    acessoDto = new Acesso_ComputadorDTO();

                    acessoDto.dataAcesso = Convert.ToDateTime(resul["date"]);
                    acessoDto.usuario = new UsuarioDTO(Convert.ToString(resul["matriculausuario"]), Convert.ToString(resul["nomeUsuario"]));
                    acessoDto.laboratorio = new LaboratorioDTO(Convert.ToString(resul["descricaoLaboratorio"]));
                    acessoDto.computador = new ComputadorDTO(Convert.ToString(resul["nomeComputador"]), Convert.ToInt32(resul["posicaoComputador"]));

                    listaAcesso.Add(acessoDto);
                }
                return listaAcesso;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao listar acessos! Erro: " + ex.Message);
                return null;
            }
            finally
            {
                try
                {
                    conn.closeConnection();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro no acesso ao fechar os parâmetros de conexão! Erro: " + ex.Message);
                }
            }
        }

        public bool excluir(DateTime? data, int escolha)
        {
            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();

                switch (escolha)
                {
                    case 0:
                        cmd.CommandText = "exec deletarAcessoDia @data";
                        break;
                    case 1:
                        cmd.CommandText = "exec deletarAcessoMes @data";
                        break;
                    case 2:
                        cmd.CommandText = "exec deletarAcessoSemestre @data";
                        break;
                    case 3:
                        cmd.CommandText = "exec deletarAcessoAno @data";
                        break;
                    case 4:
                        cmd.CommandText = "exec deletarTodosAcessos";
                        break;
                }
                
                cmd.Parameters.AddWithValue("@data", data);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao excluir acesso! Erro: " + ex.Message);
                return false;
            }
            finally
            {
                try
                {
                    conn.closeConnection();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro ao fechar os parâmetros de conexão! Erro: " + ex.Message);
                }
            }
        }
    }
}
