﻿using CMS.Domain;
using CMS.Others;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Repository
{
    public class LaboratorioDAO : IGenericDAO<LaboratorioDTO>
    {
        Conexao conn = new Conexao();
        public bool salvar(LaboratorioDTO obj)
        {
            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                if (obj.idLaboratorio == 0)
                {                   
                    cmd.CommandText = "insert into laboratorio (descricaoLaboratorio) values (@descricao)";                    
                }
                else
                {
                    cmd.CommandText = "update laboratorio set descricaoLaboratorio = @descricao " +
                    "where idLaboratorio = @id";
                    cmd.Parameters.AddWithValue("@id", obj.idLaboratorio);
                }
                cmd.Parameters.AddWithValue("@descricao", obj.descricaoLaboratorio);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch(Exception ex)
            {
                Console.WriteLine("Erro na DAO ao salvar Laboratório! Erro: " + ex.Message);
                return false;
            }
            finally
            {
                conn.closeConnection();
            }
        }

        public List<LaboratorioDTO> listar(string buscar)
        {
            List<LaboratorioDTO> listaLaboratorio = new List<LaboratorioDTO>();
            LaboratorioDTO laboratorio = null;

            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();

                if (buscar == null)
                {
                    cmd.CommandText = "select * from laboratorio";
                }
                else
                {
                    cmd.CommandText = "select * from laboratorio where like '%" + buscar + "%'";
                }
                SqlDataReader resultado = cmd.ExecuteReader();

                while (resultado.Read())
                {
                    laboratorio = new LaboratorioDTO();
                    laboratorio.idLaboratorio = Convert.ToInt32(resultado["idLaboratorio"]);
                    laboratorio.descricaoLaboratorio = resultado["descricaoLaboratorio"].ToString();
                    listaLaboratorio.Add(laboratorio);
                }
                return listaLaboratorio;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao listar laboratório! Erro: " + ex.Message);
                return null;
            }
            finally
            {
                conn.closeConnection();
            }
        }

        public LaboratorioDTO carregar(int id)
        {
            LaboratorioDTO laboratorio = new LaboratorioDTO();

            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                cmd.CommandText = "select * from laboratorio where idLaboratorio = @id";
                cmd.Parameters.AddWithValue("@id", id);
                SqlDataReader resultado = cmd.ExecuteReader();

                if (resultado.Read())
                {
                    laboratorio.idLaboratorio = Convert.ToInt32(resultado["idLaboratorio"]);
                    laboratorio.descricaoLaboratorio = resultado["descricaoLaboratorio"].ToString();
                }
                return laboratorio;

            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao carregar laboratorio! Erro: " + ex.Message);
                return null;
            }
            finally
            {
                conn.closeConnection();
            }
        }

        public bool excluir(int id)
        {
            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                cmd.CommandText = "delete from laboratorio where idLaboratorio = @id";
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao excluir laboratorio! Erro: " + ex.Message);
                return false;
            }
            finally
            {
                conn.closeConnection();
            }
        }
    }
}
