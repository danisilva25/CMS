﻿using CMS.Domain;
using CMS.Others;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Repository
{
    public class EmailDAO
    {
        Conexao conn = new Conexao();

        public Boolean trocarEmail(EmailDTO email)
        {
            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                cmd.CommandText = "select idEmail from email where emailAdmin = @email;";
                cmd.Parameters.AddWithValue("@email", email.emailAdmin);
                SqlDataReader reader = cmd.ExecuteReader();

                SqlCommand cmdSalvar = new SqlCommand();               
                cmdSalvar.Connection = conn.openConnection();
                                

                if (reader.Read())
                {
                    cmdSalvar.CommandText = "update email set emailAdmin = @emailAdmin where idEmail = " + reader["idAdmin"].ToString() + ";";
                }
                else
                {
                    cmdSalvar.CommandText = "insert into email(emailAdmin) values (@emailAdmin);";
                }
                cmdSalvar.Parameters.AddWithValue("@emailAdmin", email.emailAdmin);
                cmdSalvar.ExecuteNonQuery();
                return true;
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao salvar email no banco de dados! Erro: " + ex.Message);
                return false;
            }
            finally
            {
                try
                {
                    conn.closeConnection();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro ao fechar parâmetros de conexão! Erro: " + ex.Message);
                }
            }
        }
        public String retornaEmail()
        {
            String email = null;
            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                cmd.CommandText = "select emailAdmin from email;";
                var resul = cmd.ExecuteReader();

                if(resul.Read())
                    email = resul["emailAdmin"].ToString();
                return email;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na EmailDAO ao retornar email! Erro: " + ex.Message);
                return null;
            }
            finally
            {
                try
                {
                    conn.closeConnection();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro na Classe EmailDAO ao fechar os parâmetros de conexão! Erro: " + ex.Message);
                }
            }
        }
    }
}
