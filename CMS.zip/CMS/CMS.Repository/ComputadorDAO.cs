﻿using CMS.Domain;
using CMS.Others;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Repository
{
    public class ComputadorDAO : IGenericDAO<ComputadorDTO>
    {
        Conexao conn = new Conexao();

        public bool salvar(ComputadorDTO obj)
        {
            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();

                if (obj.idComputador == 0)
                {
                    cmd.CommandText = "insert into computador(nomeComputador, posicaoComputador, " +
                    "laboratorio) values (@nome, @posicao, @laboratorio)";
                }
                else
                {
                    cmd.CommandText = "update computador set nomeComputador = @nome, posicaoComputador"+
                        " = @posicao, laboratorio = @laboratorio where idComputador = @id";
                    cmd.Parameters.AddWithValue("@id", obj.idComputador);
                }
                cmd.Parameters.AddWithValue("@nome", obj.nomeComputador);
                cmd.Parameters.AddWithValue("@posicao", obj.posicaoComputador);
                cmd.Parameters.AddWithValue("@laboratorio", obj.laboratorio.idLaboratorio);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao salvar computador! Erro : " + ex.Message);
                return false;
            }
            finally
            {
                conn.closeConnection();
            }
        }

        public List<ComputadorDTO> listar(string buscar)
        {
            List<ComputadorDTO> listaComputador = new List<ComputadorDTO>();
            ComputadorDTO computadordto = null;

            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();

                cmd.CommandText = "select c.idcomputador, c.nomeComputador, c.posicaoComputador, " +
                    "l.idLaboratorio as 'idLaboratorio', l.descricaoLaboratorio as 'descricao' " + 
                    "from computador c inner join laboratorio l on l.idLaboratorio = c.laboratorio where c.laboratorio = @buscar " + 
                    "order by c.posicaoComputador";
                cmd.Parameters.AddWithValue("@buscar", buscar);
                var resultado = cmd.ExecuteReader();

                while (resultado.Read())
                {
                    computadordto = new ComputadorDTO();
                    computadordto.idComputador = Convert.ToInt32(resultado["idComputador"]);
                    computadordto.nomeComputador = resultado["nomeComputador"].ToString();
                    computadordto.posicaoComputador = Convert.ToInt32(resultado["posicaoComputador"]);

                    LaboratorioDTO laboratorioDto = new LaboratorioDTO();
                    laboratorioDto.idLaboratorio = Convert.ToInt32(resultado["idLaboratorio"]);
                    laboratorioDto.descricaoLaboratorio = resultado["descricao"].ToString();
                    computadordto.laboratorio = laboratorioDto;

                    listaComputador.Add(computadordto);
                }

                return listaComputador;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao listar computador! Erro : " + ex.Message);
                return null;
            }
            finally
            {
                conn.closeConnection();
            }
        }

        public ComputadorDTO carregar(int id)
        {
            ComputadorDTO computadordto = new ComputadorDTO();

            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                cmd.CommandText = "select c.idcomputador, c.nomeComputador, c.posicaoComputador, " +
                    "l.idLaboratorio as 'idLaboratorio', l.descricaoLaboratorio as 'descricao' " +
                    "from computador c inner join laboratorio l on l.idLaboratorio = c.laboratorio where idComputador = @id";
                cmd.Parameters.AddWithValue("@id", id);
                var resultado = cmd.ExecuteReader();

                if (resultado.Read())
                {
                    computadordto.idComputador = Convert.ToInt32(resultado["idComputador"]);
                    computadordto.nomeComputador = resultado["nomeComputador"].ToString();
                    computadordto.posicaoComputador = Convert.ToInt32(resultado["posicaoComputador"]);

                    LaboratorioDTO laboratorioDto = new LaboratorioDTO();
                    laboratorioDto.idLaboratorio = Convert.ToInt32(resultado["idLaboratorio"]);
                    laboratorioDto.descricaoLaboratorio = resultado["descricao"].ToString();
                    computadordto.laboratorio = laboratorioDto;
                }
                return computadordto;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao carregar computador! Erro : " + ex.Message);
                return null;
            }
            finally
            {
                conn.closeConnection();
            }
        }

        public ComputadorDTO carregarPorNome(string nome)
        {
            ComputadorDTO computadordto = new ComputadorDTO();

            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                cmd.CommandText = "select c.idcomputador, c.nomeComputador, c.posicaoComputador, " +
                    "l.idLaboratorio as 'idLaboratorio', l.descricaoLaboratorio as 'descricao' " +
                    "from computador c inner join laboratorio l on l.idLaboratorio = c.laboratorio where c.nomeComputador like '" + nome +"';";
                cmd.Parameters.AddWithValue("@nome", nome);
                var resultado = cmd.ExecuteReader();

                if (resultado.Read())
                {
                    computadordto.idComputador = Convert.ToInt32(resultado["idComputador"]);
                    computadordto.nomeComputador = resultado["nomeComputador"].ToString();
                    computadordto.posicaoComputador = Convert.ToInt32(resultado["posicaoComputador"]);

                    LaboratorioDTO laboratorioDto = new LaboratorioDTO();
                    laboratorioDto.idLaboratorio = Convert.ToInt32(resultado["idLaboratorio"]);
                    laboratorioDto.descricaoLaboratorio = resultado["descricao"].ToString();
                    computadordto.laboratorio = laboratorioDto;
                }
                return computadordto;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao carregar computador! Erro : " + ex.Message);
                return null;
            }
            finally
            {
                conn.closeConnection();
            }
        }

        public bool excluir(int id)
        {
            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                cmd.CommandText = "delete from computador where idComputador = @id";
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao excluir computador! Erro : " + ex.Message);
                return false;
            }
            finally
            {
                conn.closeConnection();
            }
        }
    }
}
