﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Domain;
using System.Data.SqlClient;
using System.Security.Cryptography;
using CMS.Others;
using System.Data;

namespace CMS.Repository
{
    public class UsuarioDAO : IGenericDAO<UsuarioDTO>
    {
        private Conexao conn = new Conexao();
        private const int SaltSize = 16;
        private const int HashSize = 20;

        public Boolean salvar(UsuarioDTO usuario)
        {
            String salt = GenerateSalt();
            String senha = HashPassword(usuario.senhaUsuario, salt);
            try
            {
                conn.openConnection();
                if (usuario.idUsuario == 0)
                {
                    String sql = "insert into usuario(nomeUsuario, matriculaUsuario, senhaUsuario, permissaoUsuario, salt) values(@nome, @matricula, @senha, @permissao, @salt)";
                    SqlCommand cmd = new SqlCommand(sql);
                    cmd.Connection = conn.openConnection(); 
                    cmd.Parameters.AddWithValue("@nome", usuario.nomeUsuario);
                    cmd.Parameters.AddWithValue("@matricula", usuario.matriculaUsuario);
                    cmd.Parameters.AddWithValue("@salt", salt);
                    cmd.Parameters.AddWithValue("@senha", senha);
                    cmd.Parameters.AddWithValue("@permissao", usuario.permissaoUsuario);
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    String sql = "update usuario set nomeUsuario = @nome, matriculaUsuario = @matricula, " +
                    "senhaUsuario = @senha, salt = @salt, permissaousuario = @permissao, senhaUsuario = @senha, salt = @salt where idUsuario = @id";
                    SqlCommand cmd = new SqlCommand(sql);
                    cmd.Connection = conn.openConnection();
                    cmd.Parameters.AddWithValue("@nome", usuario.nomeUsuario);
                    cmd.Parameters.AddWithValue("@matricula", usuario.matriculaUsuario);
                    cmd.Parameters.AddWithValue("@salt", salt);
                    cmd.Parameters.AddWithValue("@senha", senha);
                    cmd.Parameters.AddWithValue("@permissao", usuario.permissaoUsuario);
                    if (usuario.senhaUsuario != null)
                    {
                        cmd.Parameters.AddWithValue("@salt", salt);
                        cmd.Parameters.AddWithValue("@senha", senha);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@salt", "");
                        cmd.Parameters.AddWithValue("@senha", "");
                    }
                    cmd.Parameters.AddWithValue("@id", usuario.idUsuario);
                    cmd.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao conectar com o banco de dados! Erro: " + ex.Message);
                return false;
            }
            finally
            {
                conn.closeConnection();
            }
        }

        public List<UsuarioDTO> listar(String buscar)
        {
            List<UsuarioDTO> listaUsuarios = new List<UsuarioDTO>();
            UsuarioDTO usuario = null;
            try
            {
                conn.openConnection();    
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();                   
                if (buscar == null)
                {
                    cmd.CommandText = "select idUsuario, nomeUsuario, matriculaUsuario, permissaoUsuario from usuario;";
                }
                else
                {
                    cmd.CommandText = "select idUsuario, nomeUsuario, matriculaUsuario, permissaoUsuario from usuario where nomeUsuario like '%" + buscar + "%';";
                    cmd.Parameters.AddWithValue("@nomeUsuario", buscar);
                }
                SqlDataReader listaUsuario = cmd.ExecuteReader();

                while (listaUsuario.Read())
                {
                    usuario = new UsuarioDTO();
                    usuario.idUsuario = Convert.ToInt32(listaUsuario["idUsuario"]);
                    usuario.nomeUsuario = listaUsuario["nomeUsuario"].ToString();
                    usuario.matriculaUsuario = listaUsuario["matriculaUsuario"].ToString();
                    usuario.permissaoUsuario = Convert.ToInt32(listaUsuario["permissaoUsuario"]);
                    listaUsuarios.Add(usuario);
                }
                return listaUsuarios;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na dao ao lista aluno! Erro: " + ex.Message);
                return null;
            }
            finally
            {
                conn.closeConnection();
            }
        }

        public UsuarioDTO carregar(int idUsuario)
        {
            UsuarioDTO usuarioDto = null;
            try
            {
                conn.openConnection();
                String sql = "select * from usuario where idUsuario = @id";
                SqlCommand cmd = new SqlCommand(sql);
                cmd.Connection = conn.openConnection();
                cmd.Parameters.AddWithValue("@id", idUsuario);
                var resultado = cmd.ExecuteReader();

                if (resultado.Read())
                {
                    usuarioDto = new UsuarioDTO();
                    usuarioDto.idUsuario = Convert.ToInt32(resultado["idUsuario"].ToString());
                    usuarioDto.nomeUsuario = resultado["nomeUsuario"].ToString();
                    usuarioDto.matriculaUsuario = resultado["matriculaUsuario"].ToString();
                    usuarioDto.senhaUsuario = resultado["senhaUsuario"].ToString();
                    usuarioDto.salt = resultado["salt"].ToString();
                    usuarioDto.permissaoUsuario = Convert.ToInt32(resultado["permissaoUsuario"].ToString());
                }
                return usuarioDto;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ou carregar Usuario! Erro: " + ex.Message);
                return null;
            }
            finally
            {
                conn.closeConnection();
            }
        }
        public Boolean excluir(int idUsuario)
        {
            try
            {
                string sql = "delete from usuario where idUsuario = @id";
                conn.openConnection();
                SqlCommand cmd = new SqlCommand(sql);
                cmd.Connection = conn.openConnection();
                cmd.Parameters.AddWithValue("@id", idUsuario);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao excluir Usuario! Erro: " + ex.Message);
                return false;
            }
            finally
            {
                conn.closeConnection();
            }
        }
        public UsuarioDTO logar(String login, String senha)
        {
            String salt = "";
            UsuarioDTO usuario = new UsuarioDTO();
            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                cmd.CommandText = "select * from usuario where matriculaUsuario = @matricula";                
                cmd.Parameters.AddWithValue("@matricula", login);
                var resultado = cmd.ExecuteReader();

                if (resultado.Read())
                {
                    salt = resultado["salt"].ToString();
                    if (HashPassword(senha, salt).Equals(resultado["senhaUsuario"].ToString()))
                    {
                        usuario.idUsuario = Convert.ToInt32(resultado["idUsuario"]);
                        usuario.nomeUsuario = resultado["nomeUsuario"].ToString();
                        usuario.matriculaUsuario = resultado["matriculaUsuario"].ToString();
                        usuario.salt = resultado["salt"].ToString();
                        usuario.senhaUsuario = resultado["senhaUsuario"].ToString();
                        usuario.permissaoUsuario = Convert.ToInt16(resultado["permissaoUsuario"]);

                        return usuario;
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao logar! Erro: " + ex.Message);
                return null;
            }
            finally
            {
                conn.closeConnection();
            }
        }

        private String GenerateSalt()
        {
            var saltBytes = new byte[80];
            using (var provider = new RNGCryptoServiceProvider())
            {
                provider.GetNonZeroBytes(saltBytes);
            }
            return Convert.ToBase64String(saltBytes);
        }

        private string HashPassword(String senha, String salt)
        {
            int iteration = 1000;
            int nHash = 80;

            var saltBytes = Convert.FromBase64String(salt);

            using (var rfc2898DeriveBytes = new Rfc2898DeriveBytes(senha, saltBytes, iteration))
            {
                return Convert.ToBase64String(rfc2898DeriveBytes.GetBytes(nHash));
            }
        }

        public Boolean alterarSenha(String senhaAtual, String novaSenha, int idUsuario)
        {
            String saltAtual = "", senhaAtualBanco = "";
            try
            {
                conn.openConnection();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn.openConnection();
                cmd.CommandText = "select salt, senhaUsuario from usuario where idUsuario = @id";
                cmd.Parameters.AddWithValue("@id", idUsuario);
                var resul = cmd.ExecuteReader();

                if (resul.Read())
                {
                    saltAtual = resul["salt"].ToString();
                    senhaAtualBanco = resul["senhaUsuario"].ToString();
                }
                cmd.Parameters.Clear();

                if (senhaAtualBanco != HashPassword(senhaAtual, saltAtual))
                {
                    return false;
                }
                else
                {
                    String novoSalt = GenerateSalt();
                    String novoHashSenha = HashPassword(novaSenha, novoSalt);

                    SqlCommand cmdAlt = new SqlCommand();
                    cmdAlt.Connection = conn.openConnection();
                    cmdAlt.CommandText = "update usuario set senhaUsuario = @senha, salt = @salt " + 
                    "where idUsuario = @id";
                    cmdAlt.Parameters.AddWithValue("@salt", novoSalt);
                    cmdAlt.Parameters.AddWithValue("@senha", novoHashSenha);
                    cmdAlt.Parameters.AddWithValue("@id", idUsuario);
                    cmdAlt.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro na DAO ao alterar senha! Erro: " + ex.Message);
                return false;
            }
            finally
            {
                try
                {
                    conn.closeConnection();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro ao fechar conexão na func~]ao verificaSenha! Erro: " + ex.Message);
                }
            }
        }
    }
}
