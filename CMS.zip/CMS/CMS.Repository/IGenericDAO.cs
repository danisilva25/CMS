﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Repository
{
    public interface IGenericDAO<T>
    {
        Boolean salvar(T obj);
        List<T> listar(String buscar);
        T carregar(int id);
        Boolean excluir(int id);
    }
}
